# LunarHavenX 1.0.0 — launcher próprio + cliente

Projeto novo, ao lado do original (`client-mod/` é cópia intacta do mod 0.5.9-alpha; o ZIP/JAR enviados não foram alterados).

## Estado real (nada abaixo é declarado sem teste)

| Parte | Estado |
|---|---|
| `launcher-core` (JSON, HTTP, versões Mojang, bibliotecas, assets, natives, Java 8, Forge 1.8.9, comando de lançamento, login Microsoft) | Código escrito, **compila**, lógica pura coberta por **30 testes offline que passam** |
| `launcher-desktop` (janela Swing com a arte do cliente, botão JOGAR) | **Compila**; o jar roda (`--version`). A janela **não foi aberta** nesta sessão (sem tela) |
| Download real de Minecraft/Forge/Java, login Microsoft, início do jogo | **NÃO testado** (sessão sem rede e sem conta). Precisa de teste seu |
| `.exe` Windows | **Não gerado aqui.** Há script + GitHub Actions para gerar (`docs/COMPILAR.md`) |
| `.apk` Android | **Não existe ainda** (próxima etapa) |
| iOS | Só planejamento (`docs/PLANO-ANDROID-IOS.md`) |
| `client-mod` (menu/HUD/etc.) | Igual ao 0.5.9-alpha; ainda não migrado para 1.0.0 |

## Estrutura
```
launcher-core/      lógica compartilhável (sem Swing; usa HttpURLConnection, que existe no Android)
launcher-desktop/   janela Swing + assets (fundo, ícone)
client-mod/         projeto Forge original (+ prebuilt/ com o JAR 0.5.9-alpha)
tests/              CoreTests (offline)
scripts/            build.sh, build.bat, package-windows.bat
.github/workflows/  build-desktop.yml (gera o .exe no Windows da nuvem)
docs/               arquitetura, autenticação, compilação, plano Android/iOS
```

## Como funciona o JOGAR
1. Procura Java **8** (config → pasta própria → JAVA_HOME); se não achar, baixa o JRE 8 Temurin (API da Adoptium).
2. Baixa o JSON do 1.8.9 do manifesto oficial da Mojang.
3. Se "Forge" estiver marcado: baixa o instalador oficial do Forge 1.8.9 (11.15.1.2318), extrai o JSON de versão e o jar (sem abrir o instalador gráfico).
4. Baixa client.jar, bibliotecas e assets (SHA-1/tamanho verificados), extrai natives.
5. Copia `client/LunarHavenX-Client-*.jar` para `mods/` da instância.
6. Inicia o jogo com os tokens da conta Microsoft (tokens ocultados no log).

Nenhum arquivo do Minecraft é distribuído junto: tudo vem dos servidores oficiais.

# Como compilar (inclusive só pelo celular)

## Opção A — GitHub Actions (recomendado pelo celular)
1. Crie um repositório no GitHub e envie esta pasta (app GitHub ou github.com no navegador do celular).
2. Aba **Actions → "Build launcher Windows (.exe)" → Run workflow**.
3. Ao terminar, baixe o artefato **LunarHavenX-Windows** (instalador `.exe` e versão portátil).
O workflow compila, **roda os 30 testes** (falha se algum quebrar) e usa `jpackage` com o WiX já presente no runner do Windows. *Este workflow ainda não foi executado por mim; se falhar, o log mostra o passo.*

## Opção B — no PC com JDK 17+
```
scripts\build.bat              :: compila, testa, gera dist\LunarHavenX-Launcher.jar
scripts\package-windows.bat    :: instalador .exe (precisa de WiX 3.x)
scripts\package-windows.bat app-image   :: pasta com LunarHavenX.exe, sem WiX
```
Linux/macOS: `scripts/build.sh` (gera o jar; `jpackage` gera instalador do próprio SO, não `.exe`).

## Rodar sem instalar
`dist\LunarHavenX-Launcher.jar` com Java 17+: `java -jar LunarHavenX-Launcher.jar` (a pasta `client\` com o JAR do mod deve ficar ao lado).

## Mod (client-mod)
Exige JDK 8 e ForgeGradle 2.1 (Gradle 2.7) e rede para baixar o Forge. Não foi recompilado aqui; o JAR 0.5.9-alpha já está em `client-mod/prebuilt/`.

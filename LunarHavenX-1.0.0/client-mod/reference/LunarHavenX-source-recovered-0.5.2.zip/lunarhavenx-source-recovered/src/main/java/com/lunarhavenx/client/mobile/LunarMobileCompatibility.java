/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client.mobile;

import com.lunarhavenx.client.performance.LunarPerformanceManager;
import java.util.Locale;

public final class LunarMobileCompatibility {
    private static Platform platform;

    private LunarMobileCompatibility() {
    }

    public static Platform getPlatform() {
        if (platform == null) {
            platform = LunarMobileCompatibility.detectPlatform();
        }
        return platform;
    }

    public static boolean isAndroid() {
        return LunarMobileCompatibility.getPlatform() == Platform.ANDROID;
    }

    public static void applyRecommendedSettings() {
        LunarPerformanceManager manager = LunarPerformanceManager.get();
        if (LunarMobileCompatibility.isAndroid()) {
            manager.applyMobileDefaultIfUnset();
        } else {
            manager.apply();
        }
    }

    public static String getPlatformLabel() {
        switch (LunarMobileCompatibility.getPlatform()) {
            case ANDROID: {
                return "ANDROID / JAVA LAUNCHER";
            }
            case DESKTOP: {
                return "DESKTOP";
            }
        }
        return "RUNTIME DESCONHECIDO";
    }

    private static Platform detectPlatform() {
        String forced = LunarMobileCompatibility.lower(System.getProperty("lunarhavenx.platform", ""));
        if ("android".equals(forced)) {
            return Platform.ANDROID;
        }
        if ("desktop".equals(forced)) {
            return Platform.DESKTOP;
        }
        String values = LunarMobileCompatibility.lower(System.getProperty("java.runtime.name", "") + " " + System.getProperty("java.vm.name", "") + " " + System.getProperty("java.vendor", "") + " " + System.getProperty("os.name", ""));
        if (values.contains("android") || values.contains("dalvik") || values.contains("art runtime")) {
            return Platform.ANDROID;
        }
        if (values.contains("windows") || values.contains("mac") || values.contains("linux") || values.contains("unix")) {
            return Platform.DESKTOP;
        }
        return Platform.UNKNOWN;
    }

    private static String lower(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ENGLISH);
    }

    public static enum Platform {
        DESKTOP,
        ANDROID,
        UNKNOWN;

    }
}


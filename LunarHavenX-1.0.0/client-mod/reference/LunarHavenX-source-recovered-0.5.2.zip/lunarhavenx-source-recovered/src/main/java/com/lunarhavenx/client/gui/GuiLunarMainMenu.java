/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client.gui;

import com.lunarhavenx.client.config.LunarLanguageManager;
import com.lunarhavenx.client.config.LunarVisualSettings;
import com.lunarhavenx.client.gui.GuiLunarCosmetics;
import com.lunarhavenx.client.gui.GuiLunarServers;
import com.lunarhavenx.client.gui.GuiLunarSettings;
import com.lunarhavenx.client.gui.LunarButton;
import com.lunarhavenx.client.gui.LunarUi;
import com.lunarhavenx.client.performance.LunarPerformanceManager;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.GuiModList;

public class GuiLunarMainMenu
extends GuiScreen {
    private static final ResourceLocation BACKGROUND = new ResourceLocation("lunarhavenx", "textures/gui/loading_background.png");
    private static final ResourceLocation LOGO = new ResourceLocation("lunarhavenx", "textures/gui/lunarhavenx_logo.png");
    private final List<Particle> particles = new ArrayList<Particle>();
    private final Random random = new Random(1829L);
    private final LunarLanguageManager language = LunarLanguageManager.get();
    private String notice;
    private long noticeUntil;

    public void initGui() {
        this.buttonList.clear();
        this.notice = this.language.text("tagline");
        this.particles.clear();
        for (int i = 0; i < 48; ++i) {
            this.particles.add(new Particle(this.random.nextFloat(), this.random.nextFloat(), 0.15f + this.random.nextFloat() * 0.5f, this.random.nextFloat() * 6.28f));
        }
        int contentWidth = Math.min(560, this.width - 32);
        int left = (this.width - contentWidth) / 2;
        int gap = 10;
        int columnWidth = (contentWidth - gap) / 2;
        int top = Math.max(76, (this.height - 224) / 2);
        this.addButton(0, left, top, contentWidth, 36, this.language.text("play"), true);
        this.addButton(1, left, top + 42, columnWidth, 30, this.language.text("singlePlayer"));
        this.addButton(2, left + columnWidth + gap, top + 42, columnWidth, 30, this.language.text("multiplayer"));
        this.addButton(3, left, top + 78, columnWidth, 30, this.language.text("mods"));
        this.addButton(4, left + columnWidth + gap, top + 78, columnWidth, 30, this.language.text("cosmetics"));
        this.addButton(5, left, top + 114, columnWidth, 30, this.language.text("profile"));
        this.addButton(6, left + columnWidth + gap, top + 114, columnWidth, 30, this.language.text("servers"));
        this.addButton(7, left, top + 150, columnWidth, 30, this.language.text("settings"));
        this.addButton(8, left + columnWidth + gap, top + 150, columnWidth, 30, this.language.text("voice"));
        this.addButton(9, left, top + 186, contentWidth, 26, this.language.text("exit"));
    }

    private void addButton(int id, int x, int y, int w, int h, String text) {
        this.addButton(id, x, y, w, h, text, false);
    }

    private void addButton(int id, int x, int y, int w, int h, String text, boolean primary) {
        this.buttonList.add(new LunarButton(id, x, y, w, h, text, primary));
    }

    public void updateScreen() {
        if (!LunarVisualSettings.get().animationsEnabled) {
            return;
        }
        for (Particle particle : this.particles) {
            particle.phase += 0.018f;
            particle.x += 1.2E-4f * particle.speed;
            particle.y -= 8.0E-5f * particle.speed;
            if (particle.x > 1.04f) {
                particle.x = -0.04f;
            }
            if (!(particle.y < -0.04f)) continue;
            particle.y = 1.04f;
        }
    }

    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 0: 
            case 1: {
                this.mc.displayGuiScreen((GuiScreen)new GuiSelectWorld((GuiScreen)this));
                break;
            }
            case 2: {
                this.mc.displayGuiScreen((GuiScreen)new GuiMultiplayer((GuiScreen)this));
                break;
            }
            case 3: {
                this.mc.displayGuiScreen((GuiScreen)new GuiModList((GuiScreen)this));
                break;
            }
            case 4: {
                this.mc.displayGuiScreen((GuiScreen)new GuiLunarCosmetics(this));
                break;
            }
            case 5: {
                LunarPerformanceManager.get().setProfile(LunarPerformanceManager.get().getProfile().next());
                this.notice = this.language.text("profile") + ": " + this.language.performanceName(LunarPerformanceManager.get().getProfile().name());
                this.noticeUntil = Minecraft.getSystemTime() + 2400L;
                break;
            }
            case 6: {
                this.mc.displayGuiScreen((GuiScreen)new GuiLunarServers(this));
                break;
            }
            case 7: {
                this.mc.displayGuiScreen((GuiScreen)new GuiLunarSettings(this));
                break;
            }
            case 8: {
                this.notice = this.language.text("voiceUnavailable");
                this.noticeUntil = Minecraft.getSystemTime() + 3600L;
                break;
            }
            case 9: {
                this.mc.shutdown();
                break;
            }
            default: {
                this.notice = button.displayString + " estar\u00e1 dispon\u00edvel na pr\u00f3xima etapa.";
                this.noticeUntil = Minecraft.getSystemTime() + 2400L;
            }
        }
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (LunarUi.hasTexture(BACKGROUND)) {
            this.mc.getTextureManager().bindTexture(BACKGROUND);
            GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GuiLunarMainMenu.drawModalRectWithCustomSizedTexture((int)0, (int)0, (float)0.0f, (float)0.0f, (int)this.width, (int)this.height, (float)1280.0f, (float)720.0f);
        } else {
            GuiLunarMainMenu.drawRect((int)0, (int)0, (int)this.width, (int)this.height, (int)-16446684);
        }
        GuiLunarMainMenu.drawRect((int)0, (int)0, (int)this.width, (int)this.height, (int)-1979578345);
        this.drawParticles();
        int contentWidth = Math.min(560, this.width - 32);
        int left = (this.width - contentWidth) / 2;
        int top = Math.max(76, (this.height - 224) / 2);
        LunarUi.drawPanel(left - 14, top - 14, contentWidth + 28, 240, false);
        this.drawHeader();
        super.drawScreen(mouseX, mouseY, partialTicks);
        if (Minecraft.getSystemTime() < this.noticeUntil) {
            int boxWidth = Math.min(this.width - 32, 560);
            int noticeLeft = this.width / 2 - boxWidth / 2;
            LunarUi.drawPanel(noticeLeft, this.height - 36, boxWidth, 24, true);
            String clipped = this.fontRendererObj.trimStringToWidth(this.notice, boxWidth - 20);
            this.drawCenteredString(this.fontRendererObj, clipped, this.width / 2, this.height - 28, -919553);
        }
    }

    private void drawHeader() {
        LunarUi.drawPanel(18, 18, 202, 42, false);
        if (LunarUi.hasTexture(LOGO)) {
            this.mc.getTextureManager().bindTexture(LOGO);
            GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GuiLunarMainMenu.drawModalRectWithCustomSizedTexture((int)24, (int)23, (float)0.0f, (float)0.0f, (int)32, (int)32, (float)128.0f, (float)128.0f);
        }
        this.drawString(this.fontRendererObj, "LUNARHAVENX", 62, 25, -919553);
        this.drawString(this.fontRendererObj, this.language.text("clientForge"), 62, 40, -11150849);
        if (this.width >= 520) {
            String profile = this.language.text("profile") + "  " + this.language.performanceName(LunarPerformanceManager.get().getProfile().name());
            int profileWidth = this.fontRendererObj.getStringWidth(profile);
            LunarUi.drawPanel(this.width - profileWidth - 40, 18, profileWidth + 22, 42, false);
            this.drawString(this.fontRendererObj, profile, this.width - profileWidth - 29, 25, -919553);
            this.drawString(this.fontRendererObj, "v0.5.2-alpha", this.width - profileWidth - 29, 40, -6572852);
        }
        this.drawString(this.fontRendererObj, this.language.text("localClient"), 22, this.height - 18, -6572852);
    }

    private void drawParticles() {
        if (!LunarVisualSettings.get().particlesEnabled) {
            return;
        }
        for (Particle particle : this.particles) {
            int x = (int)(particle.x * (float)this.width);
            int y = (int)(particle.y * (float)this.height);
            int alpha = 75 + (int)(70.0f * (0.5f + 0.5f * (float)Math.sin(particle.phase)));
            int color = alpha << 24 | 0x66DFFF;
            GuiLunarMainMenu.drawRect((int)x, (int)y, (int)(x + 2), (int)(y + 2), (int)color);
            if (!(particle.speed > 0.55f)) continue;
            GuiLunarMainMenu.drawRect((int)(x - 3), (int)(y + 1), (int)(x + 5), (int)(y + 2), (int)color);
        }
    }

    public boolean doesGuiPauseGame() {
        return false;
    }

    private static class Particle {
        float x;
        float y;
        final float speed;
        float phase;

        Particle(float x, float y, float speed, float phase) {
            this.x = x;
            this.y = y;
            this.speed = speed;
            this.phase = phase;
        }
    }
}


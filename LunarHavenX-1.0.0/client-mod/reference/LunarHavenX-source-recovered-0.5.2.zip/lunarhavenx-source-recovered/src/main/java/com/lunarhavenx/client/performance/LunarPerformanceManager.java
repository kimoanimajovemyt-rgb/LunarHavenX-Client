/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client.performance;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

public final class LunarPerformanceManager {
    private static final LunarPerformanceManager INSTANCE = new LunarPerformanceManager();
    private final File file;
    private Profile profile = Profile.BALANCEADO;
    private boolean hasSavedProfile;

    private LunarPerformanceManager() {
        this.file = new File(Minecraft.getMinecraft().mcDataDir, "config/lunarhavenx/performance.properties");
        this.load();
    }

    public static LunarPerformanceManager get() {
        return INSTANCE;
    }

    public Profile getProfile() {
        return this.profile;
    }

    public boolean hasSavedProfile() {
        return this.hasSavedProfile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile == null ? Profile.BALANCEADO : profile;
        this.hasSavedProfile = true;
        this.apply();
        this.save();
    }

    public void applyMobileDefaultIfUnset() {
        if (!this.hasSavedProfile) {
            this.setProfile(Profile.CELULAR_FRACO);
        } else {
            this.apply();
        }
    }

    public void apply() {
        GameSettings settings = Minecraft.getMinecraft().gameSettings;
        switch (this.profile) {
            case BATATA: {
                settings.renderDistanceChunks = 2;
                settings.particleSetting = 2;
                settings.fancyGraphics = false;
                settings.ambientOcclusion = 0;
                settings.entityShadows = false;
                settings.clouds = 0;
                settings.mipmapLevels = 0;
                settings.useVbo = true;
                settings.enableVsync = false;
                settings.limitFramerate = 260;
                break;
            }
            case BAIXO: {
                settings.renderDistanceChunks = 4;
                settings.particleSetting = 2;
                settings.fancyGraphics = false;
                settings.ambientOcclusion = 0;
                settings.entityShadows = false;
                settings.clouds = 0;
                settings.mipmapLevels = 1;
                settings.useVbo = true;
                settings.enableVsync = false;
                settings.limitFramerate = 260;
                break;
            }
            case BALANCEADO: {
                settings.renderDistanceChunks = 8;
                settings.particleSetting = 1;
                settings.fancyGraphics = false;
                settings.ambientOcclusion = 1;
                settings.entityShadows = false;
                settings.clouds = 1;
                settings.mipmapLevels = 2;
                settings.useVbo = true;
                settings.enableVsync = false;
                settings.limitFramerate = 260;
                break;
            }
            case ALTO_FPS: {
                settings.renderDistanceChunks = 6;
                settings.particleSetting = 1;
                settings.fancyGraphics = false;
                settings.ambientOcclusion = 0;
                settings.entityShadows = false;
                settings.clouds = 0;
                settings.mipmapLevels = 1;
                settings.useVbo = true;
                settings.enableVsync = false;
                settings.limitFramerate = 260;
                break;
            }
            case FPS_EXTREMO: {
                settings.renderDistanceChunks = 4;
                settings.particleSetting = 2;
                settings.fancyGraphics = false;
                settings.ambientOcclusion = 0;
                settings.entityShadows = false;
                settings.clouds = 0;
                settings.mipmapLevels = 0;
                settings.useVbo = true;
                settings.enableVsync = false;
                settings.limitFramerate = 260;
                break;
            }
            case CELULAR_FRACO: {
                settings.renderDistanceChunks = 3;
                settings.particleSetting = 2;
                settings.fancyGraphics = false;
                settings.ambientOcclusion = 0;
                settings.entityShadows = false;
                settings.clouds = 0;
                settings.mipmapLevels = 0;
                settings.useVbo = true;
                settings.enableVsync = false;
                settings.limitFramerate = 60;
            }
        }
        settings.saveOptions();
    }

    public void load() {
        if (!this.file.isFile()) {
            return;
        }
        Properties properties = new Properties();
        try {
            try (FileInputStream in = new FileInputStream(this.file);){
                properties.load(in);
            }
            String saved = properties.getProperty("profile");
            if (saved != null) {
                try {
                    this.profile = Profile.valueOf(saved);
                    this.hasSavedProfile = true;
                }
                catch (IllegalArgumentException ignored) {
                    this.profile = Profile.BALANCEADO;
                    this.hasSavedProfile = false;
                }
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void save() {
        File parent = this.file.getParentFile();
        if (!parent.exists() && !parent.mkdirs()) {
            return;
        }
        Properties properties = new Properties();
        properties.setProperty("profile", this.profile.name());
        try (FileOutputStream out = new FileOutputStream(this.file);){
            properties.store(out, "LunarHavenX performance profile");
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    public static enum Profile {
        BATATA("BATATA"),
        BAIXO("BAIXO"),
        BALANCEADO("BALANCEADO"),
        ALTO_FPS("ALTO FPS"),
        FPS_EXTREMO("FPS EXTREMO"),
        CELULAR_FRACO("CELULAR FRACO");

        public final String label;

        private Profile(String label) {
            this.label = label;
        }

        public Profile next() {
            Profile[] values = Profile.values();
            return values[(this.ordinal() + 1) % values.length];
        }
    }
}


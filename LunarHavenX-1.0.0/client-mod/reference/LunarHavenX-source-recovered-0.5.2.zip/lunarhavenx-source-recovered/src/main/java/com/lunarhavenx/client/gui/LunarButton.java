/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;

public class LunarButton
extends GuiButton {
    private final boolean primary;

    public LunarButton(int id, int x, int y, int width, int height, String label) {
        this(id, x, y, width, height, label, false);
    }

    public LunarButton(int id, int x, int y, int width, int height, String label, boolean primary) {
        super(id, x, y, width, height, label);
        this.primary = primary;
    }

    public void drawButton(Minecraft mc, int mouseX, int mouseY) {
        int text;
        int accent;
        int background;
        if (!this.visible) {
            return;
        }
        boolean bl = this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
        if (!this.enabled) {
            background = -1190521823;
            accent = -13614763;
            text = -8877670;
        } else if (this.primary) {
            background = this.hovered ? -15244662 : -15709072;
            accent = this.hovered ? -4983809 : -11150849;
            text = -1;
        } else {
            background = this.hovered ? -15123883 : -385146824;
            accent = this.hovered ? -8132353 : -13543819;
            text = -919553;
        }
        Gui.drawRect((int)this.xPosition, (int)this.yPosition, (int)(this.xPosition + this.width), (int)(this.yPosition + this.height), (int)accent);
        Gui.drawRect((int)(this.xPosition + 1), (int)(this.yPosition + 1), (int)(this.xPosition + this.width - 1), (int)(this.yPosition + this.height - 1), (int)background);
        mc.fontRendererObj.drawStringWithShadow(this.displayString, (float)this.xPosition + (float)(this.width - mc.fontRendererObj.getStringWidth(this.displayString)) / 2.0f, (float)this.yPosition + (float)(this.height - 8) / 2.0f, text);
    }
}


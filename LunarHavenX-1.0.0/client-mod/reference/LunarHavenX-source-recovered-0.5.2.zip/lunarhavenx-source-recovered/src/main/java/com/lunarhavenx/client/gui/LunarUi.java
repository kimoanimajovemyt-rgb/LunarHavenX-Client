/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client.gui;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.ResourceLocation;

public final class LunarUi {
    public static final int TEXT = -919553;
    public static final int MUTED = -6572852;
    public static final int ACCENT = -11150849;
    public static final int PANEL = -385280213;
    public static final int PANEL_SOFT = -922017736;
    public static final int BORDER = -14400674;
    private static final Map<ResourceLocation, Boolean> TEXTURE_CACHE = new HashMap<ResourceLocation, Boolean>();

    private LunarUi() {
    }

    public static void drawPanel(int x, int y, int width, int height, boolean highlighted) {
        int edge = highlighted ? -11150849 : -14400674;
        Gui.drawRect((int)x, (int)y, (int)(x + width), (int)(y + height), (int)edge);
        Gui.drawRect((int)(x + 1), (int)(y + 1), (int)(x + width - 1), (int)(y + height - 1), (int)-385280213);
        Gui.drawRect((int)(x + 1), (int)(y + 1), (int)(x + width - 1), (int)(y + 2), (int)(highlighted ? -7541761 : -13543819));
    }

    public static void drawHeading(String title, String subtitle, int width, int y) {
        Minecraft mc = Minecraft.getMinecraft();
        mc.fontRendererObj.drawStringWithShadow(title, (float)(width - mc.fontRendererObj.getStringWidth(title)) / 2.0f, (float)y, -919553);
        mc.fontRendererObj.drawStringWithShadow(subtitle, (float)(width - mc.fontRendererObj.getStringWidth(subtitle)) / 2.0f, (float)(y + 17), -11150849);
    }

    public static void drawSection(String label, int x, int y) {
        Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(label, (float)x, (float)y, -11150849);
    }

    public static void drawDivider(int x, int y, int width) {
        Gui.drawRect((int)x, (int)y, (int)(x + width), (int)(y + 1), (int)-2008057706);
    }

    public static boolean hasTexture(ResourceLocation location) {
        boolean available;
        Boolean cached = TEXTURE_CACHE.get(location);
        if (cached != null) {
            return cached;
        }
        try {
            Minecraft.getMinecraft().getResourceManager().getResource(location);
            available = true;
        }
        catch (IOException ignored) {
            available = false;
        }
        TEXTURE_CACHE.put(location, available);
        return available;
    }
}


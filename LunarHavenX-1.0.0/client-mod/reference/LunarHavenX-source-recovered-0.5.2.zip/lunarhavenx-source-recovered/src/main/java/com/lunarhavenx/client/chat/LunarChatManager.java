/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client.chat;

import java.util.LinkedHashMap;
import java.util.Map;

public final class LunarChatManager {
    private static final Map<String, String> EMOJIS = new LinkedHashMap<String, String>();

    private LunarChatManager() {
    }

    public static String replaceEmojiCodes(String message) {
        if (message == null || message.length() == 0) {
            return message;
        }
        String result = message;
        for (Map.Entry<String, String> entry : EMOJIS.entrySet()) {
            result = result.replace(entry.getKey(), entry.getValue());
        }
        return result;
    }

    public static String getHelpText() {
        return ":lunar:  :heart:  :star:  :gg:  :fire:  :wave:  :check:";
    }

    static {
        EMOJIS.put(":lunar:", "\u2726");
        EMOJIS.put(":heart:", "\u2665");
        EMOJIS.put(":star:", "\u2605");
        EMOJIS.put(":gg:", "[GG]");
        EMOJIS.put(":fire:", "[FIRE]");
        EMOJIS.put(":wave:", "[HI]");
        EMOJIS.put(":check:", "[OK]");
    }
}


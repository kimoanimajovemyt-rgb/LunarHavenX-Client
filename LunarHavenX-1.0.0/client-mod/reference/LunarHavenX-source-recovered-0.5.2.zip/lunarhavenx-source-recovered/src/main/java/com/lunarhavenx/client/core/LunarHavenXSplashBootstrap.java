/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Properties;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

@IFMLLoadingPlugin.Name(value="LunarHavenX Vanilla Splash Restore")
@IFMLLoadingPlugin.MCVersion(value="1.8.9")
@IFMLLoadingPlugin.SortingIndex(value=1001)
@IFMLLoadingPlugin.TransformerExclusions(value={"com.lunarhavenx.client.core"})
public final class LunarHavenXSplashBootstrap
implements IFMLLoadingPlugin {
    private static final String OLD_LOGO_LOCATION = "lunarhavenx:textures/gui/splash_emblem.png";

    public String[] getASMTransformerClass() {
        return new String[0];
    }

    public String getModContainerClass() {
        return null;
    }

    public String getSetupClass() {
        return null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void injectData(Map<String, Object> data) {
        try {
            Object value = data == null ? null : data.get("mcLocation");
            File gameDirectory = value instanceof File ? (File)value : new File(System.getProperty("user.dir", "."));
            File configFile = new File(new File(gameDirectory, "config"), "splash.properties");
            if (!configFile.isFile()) {
                return;
            }
            Properties properties = new Properties();
            try (FileInputStream in = new FileInputStream(configFile);){
                properties.load(in);
            }
            if (!OLD_LOGO_LOCATION.equals(properties.getProperty("logoTexture", "").trim())) {
                return;
            }
            properties.setProperty("logoTexture", "textures/gui/title/mojang.png");
            this.removeIfEquals(properties, "background", "0x050B24");
            this.removeIfEquals(properties, "font", "0xD7F4FF");
            this.removeIfEquals(properties, "bar", "0x55D9FF");
            this.removeIfEquals(properties, "barBorder", "0x24435E");
            this.removeIfEquals(properties, "barBackground", "0x0B2038");
            try (FileOutputStream out = new FileOutputStream(configFile);){
                properties.store(out, "Restored Forge's stock splash after a LunarHavenX upgrade");
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private boolean removeIfEquals(Properties properties, String key, String oldValue) {
        if (!oldValue.equalsIgnoreCase(properties.getProperty(key, "").trim())) {
            return false;
        }
        properties.remove(key);
        return true;
    }

    public String getAccessTransformerClass() {
        return null;
    }
}


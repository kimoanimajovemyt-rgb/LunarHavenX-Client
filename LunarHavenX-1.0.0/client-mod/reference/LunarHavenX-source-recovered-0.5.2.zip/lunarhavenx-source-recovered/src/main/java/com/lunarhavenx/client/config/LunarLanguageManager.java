/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import net.minecraft.client.Minecraft;

public final class LunarLanguageManager {
    private static final LunarLanguageManager INSTANCE = new LunarLanguageManager();
    private static final String[] NAMES = new String[]{"Portugu\u00eas (Brasil)", "English", "Espa\u00f1ol", "\u0420\u0443\u0441\u0441\u043a\u0438\u0439", "\u65e5\u672c\u8a9e"};
    private final File file;
    private int language;

    private LunarLanguageManager() {
        this.file = new File(Minecraft.getMinecraft().mcDataDir, "config/lunarhavenx/language.properties");
        this.load();
    }

    public static LunarLanguageManager get() {
        return INSTANCE;
    }

    public int getIndex() {
        return this.language;
    }

    public String getName() {
        return NAMES[this.language];
    }

    public void next() {
        this.language = (this.language + 1) % NAMES.length;
        this.save();
    }

    public String state(boolean enabled) {
        if (this.language == 1) {
            return enabled ? "ON" : "OFF";
        }
        if (this.language == 2) {
            return enabled ? "ACTIVADO" : "DESACTIVADO";
        }
        if (this.language == 3) {
            return enabled ? "\u0412\u041a\u041b" : "\u0412\u042b\u041a\u041b";
        }
        if (this.language == 4) {
            return enabled ? "\u30aa\u30f3" : "\u30aa\u30d5";
        }
        return enabled ? "ATIVADO" : "DESATIVADO";
    }

    public String text(String key) {
        String[] values;
        switch (key) {
            case "settings": {
                values = new String[]{"CONFIGURA\u00c7\u00d5ES VISUAIS", "VISUAL SETTINGS", "AJUSTES VISUALES", "\u0412\u0418\u0417\u0423\u0410\u041b\u042c\u041d\u042b\u0415 \u041d\u0410\u0421\u0422\u0420\u041e\u0419\u041a\u0418", "\u30d3\u30b8\u30e5\u30a2\u30eb\u8a2d\u5b9a"};
                break;
            }
            case "localSaved": {
                values = new String[]{"Prefer\u00eancias locais \u2022 salvas automaticamente", "Local preferences \u2022 saved automatically", "Preferencias locales \u2022 guardado autom\u00e1tico", "\u041b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u2022 \u0430\u0432\u0442\u043e\u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0438\u0435", "\u30ed\u30fc\u30ab\u30eb\u8a2d\u5b9a \u2022 \u81ea\u52d5\u4fdd\u5b58"};
                break;
            }
            case "hudModules": {
                values = new String[]{"M\u00d3DULOS DO HUD", "HUD MODULES", "M\u00d3DULOS DEL HUD", "\u041c\u041e\u0414\u0423\u041b\u0418 HUD", "HUD \u30e2\u30b8\u30e5\u30fc\u30eb"};
                break;
            }
            case "hud": {
                values = new String[]{"HUD", "HUD", "HUD", "HUD", "HUD"};
                break;
            }
            case "coords": {
                values = new String[]{"COORDENADAS", "COORDINATES", "COORDENADAS", "\u041a\u041e\u041e\u0420\u0414\u0418\u041d\u0410\u0422\u042b", "\u5ea7\u6a19"};
                break;
            }
            case "status": {
                values = new String[]{"STATUS", "STATUS", "ESTADO", "\u0421\u0422\u0410\u0422\u0423\u0421", "\u30b9\u30c6\u30fc\u30bf\u30b9"};
                break;
            }
            case "armor": {
                values = new String[]{"ARMADURA", "ARMOR", "ARMADURA", "\u0411\u0420\u041e\u041d\u042f", "\u9632\u5177"};
                break;
            }
            case "animations": {
                values = new String[]{"ANIMA\u00c7\u00d5ES", "ANIMATIONS", "ANIMACIONES", "\u0410\u041d\u0418\u041c\u0410\u0426\u0418\u0418", "\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3"};
                break;
            }
            case "particles": {
                values = new String[]{"PART\u00cdCULAS", "PARTICLES", "PART\u00cdCULAS", "\u0427\u0410\u0421\u0422\u0418\u0426\u042b", "\u30d1\u30fc\u30c6\u30a3\u30af\u30eb"};
                break;
            }
            case "cps": {
                values = new String[]{"CPS", "CPS", "CPS", "CPS", "CPS"};
                break;
            }
            case "keys": {
                values = new String[]{"TECLAS", "KEYSTROKES", "TECLAS", "\u041a\u041b\u0410\u0412\u0418\u0428\u0418", "\u30ad\u30fc\u8868\u793a"};
                break;
            }
            case "profile": {
                values = new String[]{"PERFIL", "PROFILE", "PERFIL", "\u041f\u0420\u041e\u0424\u0418\u041b\u042c", "\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb"};
                break;
            }
            case "shortcuts": {
                values = new String[]{"ATALHOS E MACROS", "KEYBINDS & MACROS", "ATAJOS Y MACROS", "\u041a\u041b\u0410\u0412\u0418\u0428\u0418 \u0418 \u041c\u0410\u041a\u0420\u041e\u0421\u042b", "\u30ad\u30fc\u8a2d\u5b9a\u3068\u30de\u30af\u30ed"};
                break;
            }
            case "modules": {
                values = new String[]{"M\u00d3DULOS", "MODULES", "M\u00d3DULOS", "\u041c\u041e\u0414\u0423\u041b\u0418", "\u30e2\u30b8\u30e5\u30fc\u30eb"};
                break;
            }
            case "language": {
                values = new String[]{"IDIOMA", "LANGUAGE", "IDIOMA", "\u042f\u0417\u042b\u041a", "\u8a00\u8a9e"};
                break;
            }
            case "restore": {
                values = new String[]{"RESTAURAR PADR\u00d5ES", "RESTORE DEFAULTS", "RESTAURAR VALORES", "\u0421\u0411\u0420\u041e\u0421\u0418\u0422\u042c \u041d\u0410\u0421\u0422\u0420\u041e\u0419\u041a\u0418", "\u521d\u671f\u8a2d\u5b9a\u306b\u623b\u3059"};
                break;
            }
            case "done": {
                values = new String[]{"CONCLU\u00cdDO", "DONE", "LISTO", "\u0413\u041e\u0422\u041e\u0412\u041e", "\u5b8c\u4e86"};
                break;
            }
            case "opacity": {
                values = new String[]{"OPACIDADE DO HUD", "HUD OPACITY", "OPACIDAD DEL HUD", "\u041f\u0420\u041e\u0417\u0420\u0410\u0427\u041d\u041e\u0421\u0422\u042c HUD", "HUD \u306e\u4e0d\u900f\u660e\u5ea6"};
                break;
            }
            case "scale": {
                values = new String[]{"ESCALA DA INTERFACE", "INTERFACE SCALE", "ESCALA DE INTERFAZ", "\u041c\u0410\u0421\u0428\u0422\u0410\u0411 \u0418\u041d\u0422\u0415\u0420\u0424\u0415\u0419\u0421\u0410", "UI \u30b9\u30b1\u30fc\u30eb"};
                break;
            }
            case "profileInfo": {
                values = new String[]{"Perfis ajustam gr\u00e1ficos; PvP n\u00e3o automatiza a\u00e7\u00f5es.", "Profiles tune graphics; PvP never automates actions.", "Los perfiles ajustan gr\u00e1ficos; PvP no automatiza acciones.", "\u041f\u0440\u043e\u0444\u0438\u043b\u0438 \u043d\u0430\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u044e\u0442 \u0433\u0440\u0430\u0444\u0438\u043a\u0443; PvP \u043d\u0435 \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0437\u0438\u0440\u0443\u0435\u0442 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044f.", "\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u306f\u753b\u8cea\u3092\u8abf\u6574\u3057\u3001PvP\u64cd\u4f5c\u306f\u81ea\u52d5\u5316\u3057\u307e\u305b\u3093\u3002"};
                break;
            }
            case "quickHelp": {
                values = new String[]{"RSHIFT abre configura\u00e7\u00f5es \u2022 apenas ajustes locais.", "RSHIFT opens settings \u2022 local changes only.", "RSHIFT abre ajustes \u2022 solo cambios locales.", "RSHIFT \u043e\u0442\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u2022 \u0442\u043e\u043b\u044c\u043a\u043e \u043b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0435 \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b.", "RSHIFT \u3067\u8a2d\u5b9a\u3092\u958b\u304f \u2022 \u30ed\u30fc\u30ab\u30eb\u8a2d\u5b9a\u306e\u307f\u3002"};
                break;
            }
            case "moduleTitle": {
                values = new String[]{"M\u00d3DULOS DO CLIENTE", "CLIENT MODULES", "M\u00d3DULOS DEL CLIENTE", "\u041c\u041e\u0414\u0423\u041b\u0418 \u041a\u041b\u0418\u0415\u041d\u0422\u0410", "\u30af\u30e9\u30a4\u30a2\u30f3\u30c8\u30e2\u30b8\u30e5\u30fc\u30eb"};
                break;
            }
            case "moduleHelp": {
                values = new String[]{"Informa\u00e7\u00f5es locais e visuais; sem vantagens ocultas.", "Local and visual information; no hidden advantages.", "Informaci\u00f3n local y visual; sin ventajas ocultas.", "\u041b\u043e\u043a\u0430\u043b\u044c\u043d\u0430\u044f \u0438 \u0432\u0438\u0437\u0443\u0430\u043b\u044c\u043d\u0430\u044f \u0438\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f; \u0431\u0435\u0437 \u0441\u043a\u0440\u044b\u0442\u044b\u0445 \u043f\u0440\u0435\u0438\u043c\u0443\u0449\u0435\u0441\u0442\u0432.", "\u30ed\u30fc\u30ab\u30eb\u30fb\u8996\u899a\u60c5\u5831\u306e\u307f\u3002\u96a0\u308c\u305f\u512a\u4f4d\u6a5f\u80fd\u306f\u3042\u308a\u307e\u305b\u3093\u3002"};
                break;
            }
            case "clock": {
                values = new String[]{"REL\u00d3GIO", "CLOCK", "RELOJ", "\u0427\u0410\u0421\u042b", "\u6642\u8a08"};
                break;
            }
            case "biome": {
                values = new String[]{"BIOMA", "BIOME", "BIOMA", "\u0411\u0418\u041e\u041c", "\u30d0\u30a4\u30aa\u30fc\u30e0"};
                break;
            }
            case "direction": {
                values = new String[]{"DIRE\u00c7\u00c3O", "DIRECTION", "DIRECCI\u00d3N", "\u041d\u0410\u041f\u0420\u0410\u0412\u041b\u0415\u041d\u0418\u0415", "\u65b9\u89d2"};
                break;
            }
            case "profiles": {
                values = new String[]{"PERFIS DE JOGO", "GAME PROFILES", "PERFILES DE JUEGO", "\u0418\u0413\u0420\u041e\u0412\u042b\u0415 \u041f\u0420\u041e\u0424\u0418\u041b\u0418", "\u30b2\u30fc\u30e0\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb"};
                break;
            }
            case "profileHelp": {
                values = new String[]{"6 espa\u00e7os com nomes pr\u00f3prios \u2022 importar e exportar arquivos locais", "6 named slots \u2022 import and export local profile files", "6 espacios con nombre \u2022 importar y exportar perfiles locales", "6 \u0441\u043b\u043e\u0442\u043e\u0432 \u0441 \u0438\u043c\u0435\u043d\u0430\u043c\u0438 \u2022 \u0438\u043c\u043f\u043e\u0440\u0442 \u0438 \u044d\u043a\u0441\u043f\u043e\u0440\u0442 \u043b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0445 \u043f\u0440\u043e\u0444\u0438\u043b\u0435\u0439", "6 \u500b\u306e\u540d\u524d\u4ed8\u304d\u30b9\u30ed\u30c3\u30c8 \u2022 \u30ed\u30fc\u30ab\u30eb\u8a2d\u5b9a\u3092\u30a4\u30f3\u30dd\u30fc\u30c8\u30fb\u30a8\u30af\u30b9\u30dd\u30fc\u30c8"};
                break;
            }
            case "apply": {
                values = new String[]{"APLICAR", "APPLY", "APLICAR", "\u041f\u0420\u0418\u041c\u0415\u041d\u0418\u0422\u042c", "\u9069\u7528"};
                break;
            }
            case "save": {
                values = new String[]{"SALVAR ATUAL", "SAVE CURRENT", "GUARDAR ACTUAL", "\u0421\u041e\u0425\u0420\u0410\u041d\u0418\u0422\u042c \u0422\u0415\u041a\u0423\u0429\u0415\u0415", "\u73fe\u5728\u306e\u8a2d\u5b9a\u3092\u4fdd\u5b58"};
                break;
            }
            case "pvp": {
                values = new String[]{"PVP", "PVP", "PVP", "PVP", "PvP"};
                break;
            }
            case "balanced": {
                values = new String[]{"GERAL", "BALANCED", "EQUILIBRADO", "\u0421\u0411\u0410\u041b\u0410\u041d\u0421\u0418\u0420\u041e\u0412\u0410\u041d\u041d\u042b\u0419", "\u6a19\u6e96"};
                break;
            }
            case "light": {
                values = new String[]{"LEVE", "LOW-END", "LIGERO", "\u041b\u0401\u0413\u041a\u0418\u0419", "\u8efd\u91cf"};
                break;
            }
            case "clockValue": {
                values = new String[]{"Hora local", "Local time", "Hora local", "\u041c\u0435\u0441\u0442\u043d\u043e\u0435 \u0432\u0440\u0435\u043c\u044f", "\u73fe\u5730\u6642\u523b"};
                break;
            }
            case "biomeValue": {
                values = new String[]{"Bioma atual", "Current biome", "Bioma actual", "\u0422\u0435\u043a\u0443\u0449\u0438\u0439 \u0431\u0438\u043e\u043c", "\u73fe\u5728\u306e\u30d0\u30a4\u30aa\u30fc\u30e0"};
                break;
            }
            case "directionValue": {
                values = new String[]{"Dire\u00e7\u00e3o da c\u00e2mera", "Camera direction", "Direcci\u00f3n de c\u00e1mara", "\u041d\u0430\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 \u043a\u0430\u043c\u0435\u0440\u044b", "\u30ab\u30e1\u30e9\u306e\u65b9\u89d2"};
                break;
            }
            case "moduleTitleHud": {
                values = new String[]{"HUD E INFORMA\u00c7\u00d5ES", "HUD & INFORMATION", "HUD E INFORMACI\u00d3N", "HUD \u0418 \u0418\u041d\u0424\u041e\u0420\u041c\u0410\u0426\u0418\u042f", "HUD \u3068\u60c5\u5831"};
                break;
            }
            case "moduleTitleVisual": {
                values = new String[]{"VISUAL", "VISUAL", "VISUAL", "\u0412\u0418\u0417\u0423\u0410\u041b\u042c\u041d\u041e\u0415", "\u30d3\u30b8\u30e5\u30a2\u30eb"};
                break;
            }
            case "tagline": {
                values = new String[]{"Mais que um cliente, um novo horizonte.", "More than a client, a new horizon.", "M\u00e1s que un cliente, un nuevo horizonte.", "\u0411\u043e\u043b\u044c\u0448\u0435, \u0447\u0435\u043c \u043a\u043b\u0438\u0435\u043d\u0442 \u2014 \u043d\u043e\u0432\u044b\u0439 \u0433\u043e\u0440\u0438\u0437\u043e\u043d\u0442.", "\u30af\u30e9\u30a4\u30a2\u30f3\u30c8\u4ee5\u4e0a\u306e\u3001\u65b0\u3057\u3044\u5730\u5e73\u7dda\u3002"};
                break;
            }
            case "play": {
                values = new String[]{"JOGAR AGORA", "PLAY NOW", "JUGAR AHORA", "\u0418\u0413\u0420\u0410\u0422\u042c", "\u4eca\u3059\u3050\u30d7\u30ec\u30a4"};
                break;
            }
            case "singlePlayer": {
                values = new String[]{"UM JOGADOR", "SINGLEPLAYER", "UN JUGADOR", "\u041e\u0414\u0418\u041d\u041e\u0427\u041d\u0410\u042f \u0418\u0413\u0420\u0410", "\u30b7\u30f3\u30b0\u30eb\u30d7\u30ec\u30a4"};
                break;
            }
            case "multiplayer": {
                values = new String[]{"MULTIJOGADOR", "MULTIPLAYER", "MULTIJUGADOR", "\u0421\u0415\u0422\u0415\u0412\u0410\u042f \u0418\u0413\u0420\u0410", "\u30de\u30eb\u30c1\u30d7\u30ec\u30a4"};
                break;
            }
            case "mods": {
                values = new String[]{"MODS", "MODS", "MODS", "\u041c\u041e\u0414\u042b", "MOD"};
                break;
            }
            case "cosmetics": {
                values = new String[]{"COSM\u00c9TICOS", "COSMETICS", "COSM\u00c9TICOS", "\u041a\u041e\u0421\u041c\u0415\u0422\u0418\u041a\u0410", "\u30b3\u30b9\u30e1"};
                break;
            }
            case "servers": {
                values = new String[]{"SERVIDORES", "SERVERS", "SERVIDORES", "\u0421\u0415\u0420\u0412\u0415\u0420\u042b", "\u30b5\u30fc\u30d0\u30fc"};
                break;
            }
            case "voice": {
                values = new String[]{"CHAT DE VOZ", "VOICE CHAT", "CHAT DE VOZ", "\u0413\u041e\u041b\u041e\u0421\u041e\u0412\u041e\u0419 \u0427\u0410\u0422", "\u30dc\u30a4\u30b9\u30c1\u30e3\u30c3\u30c8"};
                break;
            }
            case "exit": {
                values = new String[]{"SAIR", "EXIT", "SALIR", "\u0412\u042b\u0425\u041e\u0414", "\u7d42\u4e86"};
                break;
            }
            case "clientForge": {
                values = new String[]{"CLIENTE \u2022 FORGE 1.8.9", "CLIENT \u2022 FORGE 1.8.9", "CLIENTE \u2022 FORGE 1.8.9", "\u041a\u041b\u0418\u0415\u041d\u0422 \u2022 FORGE 1.8.9", "\u30af\u30e9\u30a4\u30a2\u30f3\u30c8 \u2022 FORGE 1.8.9"};
                break;
            }
            case "localClient": {
                values = new String[]{"LUNARHAVENX \u2022 CLIENTE LOCAL", "LUNARHAVENX \u2022 LOCAL CLIENT", "LUNARHAVENX \u2022 CLIENTE LOCAL", "LUNARHAVENX \u2022 \u041b\u041e\u041a\u0410\u041b\u042c\u041d\u042b\u0419 \u041a\u041b\u0418\u0415\u041d\u0422", "LUNARHAVENX \u2022 \u30ed\u30fc\u30ab\u30eb\u30af\u30e9\u30a4\u30a2\u30f3\u30c8"};
                break;
            }
            case "voiceUnavailable": {
                values = new String[]{"Simple Voice Chat n\u00e3o lista uma vers\u00e3o Forge 1.8.9; voz exige cliente e servidor compat\u00edveis.", "Simple Voice Chat has no listed Forge 1.8.9 build; voice requires compatible client and server.", "Simple Voice Chat no tiene una versi\u00f3n Forge 1.8.9; requiere cliente y servidor compatibles.", "\u0414\u043b\u044f Forge 1.8.9 \u043d\u0435\u0442 \u0432\u0435\u0440\u0441\u0438\u0438 Simple Voice Chat; \u043d\u0443\u0436\u043d\u044b \u0441\u043e\u0432\u043c\u0435\u0441\u0442\u0438\u043c\u044b\u0435 \u043a\u043b\u0438\u0435\u043d\u0442 \u0438 \u0441\u0435\u0440\u0432\u0435\u0440.", "Simple Voice Chat \u306b Forge 1.8.9 \u7248\u306f\u3042\u308a\u307e\u305b\u3093\u3002\u5bfe\u5fdc\u3059\u308b\u30af\u30e9\u30a4\u30a2\u30f3\u30c8\u3068\u30b5\u30fc\u30d0\u30fc\u304c\u5fc5\u8981\u3067\u3059\u3002"};
                break;
            }
            case "previous": {
                values = new String[]{"ANTERIOR", "PREVIOUS", "ANTERIOR", "\u041d\u0410\u0417\u0410\u0414", "\u524d\u3078"};
                break;
            }
            case "equip": {
                values = new String[]{"EQUIPAR", "EQUIP", "EQUIPAR", "\u041d\u0410\u0414\u0415\u0422\u042c", "\u88c5\u5099"};
                break;
            }
            case "next": {
                values = new String[]{"PR\u00d3XIMA", "NEXT", "SIGUIENTE", "\u0414\u0410\u041b\u0415\u0415", "\u6b21\u3078"};
                break;
            }
            case "back": {
                values = new String[]{"VOLTAR", "BACK", "VOLVER", "\u041d\u0410\u0417\u0410\u0414", "\u623b\u308b"};
                break;
            }
            case "cosmeticSubtitle": {
                values = new String[]{"Pr\u00e9-visualiza\u00e7\u00e3o e sele\u00e7\u00e3o local", "Preview and local selection", "Vista previa y selecci\u00f3n local", "\u041f\u0440\u0435\u0434\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440 \u0438 \u043b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0439 \u0432\u044b\u0431\u043e\u0440", "\u30d7\u30ec\u30d3\u30e5\u30fc\u3068\u30ed\u30fc\u30ab\u30eb\u9078\u629e"};
                break;
            }
            case "textureMissing": {
                values = new String[]{"TEXTURA INDISPON\u00cdVEL", "TEXTURE UNAVAILABLE", "TEXTURA NO DISPONIBLE", "\u0422\u0415\u041a\u0421\u0422\u0423\u0420\u0410 \u041d\u0415\u0414\u041e\u0421\u0422\u0423\u041f\u041d\u0410", "\u30c6\u30af\u30b9\u30c1\u30e3\u3092\u5229\u7528\u3067\u304d\u307e\u305b\u3093"};
                break;
            }
            case "noCape": {
                values = new String[]{"SEM CAPA", "NO CAPE", "SIN CAPA", "\u0411\u0415\u0417 \u041f\u041b\u0410\u0429\u0410", "\u30de\u30f3\u30c8\u306a\u3057"};
                break;
            }
            case "selectedCape": {
                values = new String[]{"CAPA SELECIONADA", "SELECTED CAPE", "CAPA SELECCIONADA", "\u0412\u042b\u0411\u0420\u0410\u041d\u041d\u042b\u0419 \u041f\u041b\u0410\u0429", "\u9078\u629e\u4e2d\u306e\u30de\u30f3\u30c8"};
                break;
            }
            case "elyByInfo": {
                values = new String[]{"Skins Ely.by aparecem para todos quando o servidor usa o sistema oficial.", "Ely.by skins are visible to everyone when the server uses its official system.", "Las skins Ely.by son visibles para todos si el servidor usa el sistema oficial.", "\u0421\u043a\u0438\u043d\u044b Ely.by \u0432\u0438\u0434\u043d\u044b \u0432\u0441\u0435\u043c \u043d\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0430\u0445 \u0441 \u043e\u0444\u0438\u0446\u0438\u0430\u043b\u044c\u043d\u043e\u0439 \u0441\u0438\u0441\u0442\u0435\u043c\u043e\u0439.", "\u30b5\u30fc\u30d0\u30fc\u304c\u516c\u5f0f\u30b7\u30b9\u30c6\u30e0\u3092\u4f7f\u3046\u3068 Ely.by \u30b9\u30ad\u30f3\u304c\u5168\u54e1\u306b\u8868\u793a\u3055\u308c\u307e\u3059\u3002"};
                break;
            }
            case "elyByHelp": {
                values = new String[]{"Configure sua skin na conta Ely.by e entre em um servidor compat\u00edvel.", "Set your skin on Ely.by and join a compatible server.", "Configura tu skin en Ely.by y entra a un servidor compatible.", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u0442\u0435 \u0441\u043a\u0438\u043d \u0432 Ely.by \u0438 \u0437\u0430\u0439\u0434\u0438\u0442\u0435 \u043d\u0430 \u0441\u043e\u0432\u043c\u0435\u0441\u0442\u0438\u043c\u044b\u0439 \u0441\u0435\u0440\u0432\u0435\u0440.", "Ely.by \u3067\u30b9\u30ad\u30f3\u3092\u8a2d\u5b9a\u3057\u3001\u5bfe\u5fdc\u30b5\u30fc\u30d0\u30fc\u306b\u53c2\u52a0\u3057\u3066\u304f\u3060\u3055\u3044\u3002"};
                break;
            }
            case "localCapeInfo": {
                values = new String[]{"As capas LunarHavenX desta tela continuam sendo cosm\u00e9ticos locais.", "LunarHavenX capes on this screen remain local cosmetics.", "Las capas LunarHavenX de esta pantalla son cosm\u00e9ticos locales.", "\u041f\u043b\u0430\u0449\u0438 LunarHavenX \u043d\u0430 \u044d\u0442\u043e\u043c \u044d\u043a\u0440\u0430\u043d\u0435 \u0432\u0438\u0434\u043d\u044b \u0442\u043e\u043b\u044c\u043a\u043e \u0432\u0430\u043c.", "\u3053\u306e\u753b\u9762\u306e LunarHavenX \u30de\u30f3\u30c8\u306f\u81ea\u5206\u3060\u3051\u306b\u8868\u793a\u3055\u308c\u307e\u3059\u3002"};
                break;
            }
            case "equipped": {
                values = new String[]{"Cosm\u00e9tico", "Cosmetic", "Cosm\u00e9tico", "\u041a\u043e\u0441\u043c\u0435\u0442\u0438\u043a\u0430", "\u30b3\u30b9\u30e1"};
                break;
            }
            case "equippedLocal": {
                values = new String[]{"equipado localmente.", "equipped locally.", "equipado localmente.", "\u043d\u0430\u0434\u0435\u0442\u0430 \u043b\u043e\u043a\u0430\u043b\u044c\u043d\u043e.", "\u3092\u30ed\u30fc\u30ab\u30eb\u3067\u88c5\u5099\u3057\u307e\u3057\u305f\u3002"};
                break;
            }
            case "connect": {
                values = new String[]{"CONECTAR", "CONNECT", "CONECTAR", "\u041f\u041e\u0414\u041a\u041b\u042e\u0427\u0418\u0422\u042c\u0421\u042f", "\u63a5\u7d9a"};
                break;
            }
            case "add": {
                values = new String[]{"ADICIONAR", "ADD", "A\u00d1ADIR", "\u0414\u041e\u0411\u0410\u0412\u0418\u0422\u042c", "\u8ffd\u52a0"};
                break;
            }
            case "remove": {
                values = new String[]{"REMOVER", "REMOVE", "ELIMINAR", "\u0423\u0414\u0410\u041b\u0418\u0422\u042c", "\u524a\u9664"};
                break;
            }
            case "refresh": {
                values = new String[]{"ATUALIZAR", "REFRESH", "ACTUALIZAR", "\u041e\u0411\u041d\u041e\u0412\u0418\u0422\u042c", "\u66f4\u65b0"};
                break;
            }
            case "favorites": {
                values = new String[]{"FAVORITOS SALVOS", "SAVED FAVORITES", "FAVORITOS GUARDADOS", "\u0421\u041e\u0425\u0420\u0410\u041d\u0401\u041d\u041d\u042b\u0415", "\u4fdd\u5b58\u6e08\u307f\u306e\u304a\u6c17\u306b\u5165\u308a"};
                break;
            }
            case "serverSubtitle": {
                values = new String[]{"Seus favoritos \u2022 armazenamento vanilla", "Your favorites \u2022 vanilla storage", "Tus favoritos \u2022 almacenamiento vanilla", "\u0418\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435 \u2022 \u0445\u0440\u0430\u043d\u0438\u043b\u0438\u0449\u0435 Minecraft", "\u304a\u6c17\u306b\u5165\u308a \u2022 Minecraft \u6a19\u6e96\u4fdd\u5b58"};
                break;
            }
            case "serverEmpty": {
                values = new String[]{"Nenhum servidor salvo. Adicione um favorito abaixo.", "No saved servers. Add a favorite below.", "No hay servidores guardados. A\u00f1ade uno abajo.", "\u041d\u0435\u0442 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0445 \u0441\u0435\u0440\u0432\u0435\u0440\u043e\u0432. \u0414\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u0441\u0435\u0440\u0432\u0435\u0440 \u043d\u0438\u0436\u0435.", "\u4fdd\u5b58\u6e08\u307f\u30b5\u30fc\u30d0\u30fc\u306f\u3042\u308a\u307e\u305b\u3093\u3002\u4e0b\u304b\u3089\u8ffd\u52a0\u3057\u3066\u304f\u3060\u3055\u3044\u3002"};
                break;
            }
            case "serverHint": {
                values = new String[]{"Clique duas vezes ou selecione e conecte \u2022 scroll para navegar", "Double-click, or select and connect \u2022 scroll to browse", "Doble clic o selecciona y conecta \u2022 usa scroll", "\u0414\u0432\u0430\u0436\u0434\u044b \u0449\u0451\u043b\u043a\u043d\u0438\u0442\u0435 \u0438\u043b\u0438 \u0432\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0438 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u0435\u0441\u044c \u2022 \u043f\u0440\u043e\u043a\u0440\u0443\u0442\u043a\u0430", "\u30c0\u30d6\u30eb\u30af\u30ea\u30c3\u30af\u3001\u307e\u305f\u306f\u9078\u629e\u3057\u3066\u63a5\u7d9a \u2022 \u30b9\u30af\u30ed\u30fc\u30eb\u3067\u79fb\u52d5"};
                break;
            }
            case "name": {
                values = new String[]{"NOME", "NAME", "NOMBRE", "\u041d\u0410\u0417\u0412\u0410\u041d\u0418\u0415", "\u540d\u524d"};
                break;
            }
            case "address": {
                values = new String[]{"ENDERE\u00c7O", "ADDRESS", "DIRECCI\u00d3N", "\u0410\u0414\u0420\u0415\u0421", "\u30a2\u30c9\u30ec\u30b9"};
                break;
            }
            case "pingUnknown": {
                values = new String[]{"ping n\u00e3o medido", "ping not measured", "ping no medido", "\u043f\u0438\u043d\u0433 \u043d\u0435 \u0438\u0437\u043c\u0435\u0440\u0435\u043d", "ping \u672a\u8a08\u6e2c"};
                break;
            }
            case "serverSelect": {
                values = new String[]{"Selecione um servidor salvo ou adicione um favorito.", "Select a saved server or add a favorite.", "Selecciona un servidor guardado o a\u00f1ade uno.", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0435\u0440\u0432\u0435\u0440 \u0438\u043b\u0438 \u0434\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435.", "\u4fdd\u5b58\u6e08\u307f\u30b5\u30fc\u30d0\u30fc\u3092\u9078\u629e\u3059\u308b\u304b\u8ffd\u52a0\u3057\u3066\u304f\u3060\u3055\u3044\u3002"};
                break;
            }
            case "serverRemoved": {
                values = new String[]{"Favorito removido.", "Favorite removed.", "Favorito eliminado.", "\u0421\u0435\u0440\u0432\u0435\u0440 \u0443\u0434\u0430\u043b\u0451\u043d \u0438\u0437 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0433\u043e.", "\u304a\u6c17\u306b\u5165\u308a\u3092\u524a\u9664\u3057\u307e\u3057\u305f\u3002"};
                break;
            }
            case "serverUpdated": {
                values = new String[]{"Lista de favoritos atualizada.", "Favorites list refreshed.", "Lista de favoritos actualizada.", "\u0421\u043f\u0438\u0441\u043e\u043a \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0433\u043e \u043e\u0431\u043d\u043e\u0432\u043b\u0451\u043d.", "\u304a\u6c17\u306b\u5165\u308a\u4e00\u89a7\u3092\u66f4\u65b0\u3057\u307e\u3057\u305f\u3002"};
                break;
            }
            case "serverChoose": {
                values = new String[]{"Escolha um servidor antes de conectar.", "Choose a server before connecting.", "Elige un servidor antes de conectar.", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0435\u0440\u0432\u0435\u0440 \u0434\u043b\u044f \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f.", "\u63a5\u7d9a\u3059\u308b\u30b5\u30fc\u30d0\u30fc\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002"};
                break;
            }
            case "serverAddressMissing": {
                values = new String[]{"Informe o endere\u00e7o do servidor.", "Enter the server address.", "Introduce la direcci\u00f3n del servidor.", "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0430\u0434\u0440\u0435\u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430.", "\u30b5\u30fc\u30d0\u30fc\u30a2\u30c9\u30ec\u30b9\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002"};
                break;
            }
            case "serverAdded": {
                values = new String[]{"Servidor adicionado aos favoritos.", "Server added to favorites.", "Servidor a\u00f1adido a favoritos.", "\u0421\u0435\u0440\u0432\u0435\u0440 \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0432 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435.", "\u30b5\u30fc\u30d0\u30fc\u3092\u304a\u6c17\u306b\u5165\u308a\u306b\u8ffd\u52a0\u3057\u307e\u3057\u305f\u3002"};
                break;
            }
            case "keyTitle": {
                values = new String[]{"ATALHOS E MACROS", "KEYBINDS & MACROS", "ATAJOS Y MACROS", "\u041a\u041b\u0410\u0412\u0418\u0428\u0418 \u0418 \u041c\u0410\u041a\u0420\u041e\u0421\u042b", "\u30ad\u30fc\u8a2d\u5b9a\u3068\u30de\u30af\u30ed"};
                break;
            }
            case "keySubtitle": {
                values = new String[]{"Atalhos locais \u2022 sem automa\u00e7\u00e3o de combate", "Local keybinds \u2022 no combat automation", "Atajos locales \u2022 sin automatizaci\u00f3n de combate", "\u041b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0435 \u043a\u043b\u0430\u0432\u0438\u0448\u0438 \u2022 \u0431\u0435\u0437 \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0437\u0430\u0446\u0438\u0438 \u0431\u043e\u044f", "\u30ed\u30fc\u30ab\u30eb\u30ad\u30fc\u8a2d\u5b9a \u2022 \u6226\u95d8\u306e\u81ea\u52d5\u5316\u306a\u3057"};
                break;
            }
            case "controls": {
                values = new String[]{"CONTROLES", "CONTROLS", "CONTROLES", "\u0423\u041f\u0420\u0410\u0412\u041b\u0415\u041d\u0418\u0415", "\u64cd\u4f5c"};
                break;
            }
            case "chatMacros": {
                values = new String[]{"MACROS DE CHAT OPCIONAIS", "OPTIONAL CHAT MACROS", "MACROS DE CHAT OPCIONALES", "\u041d\u0415\u041e\u0411\u042f\u0417\u0410\u0422\u0415\u041b\u042c\u041d\u042b\u0415 \u041c\u0410\u041a\u0420\u041e\u0421\u042b \u0427\u0410\u0422\u0410", "\u30c1\u30e3\u30c3\u30c8\u30de\u30af\u30ed\uff08\u4efb\u610f\uff09"};
                break;
            }
            case "oneMessage": {
                values = new String[]{"Uma mensagem por tecla pressionada.", "One message per key press.", "Un mensaje por pulsaci\u00f3n.", "\u041e\u0434\u043d\u043e \u0441\u043e\u043e\u0431\u0449\u0435\u043d\u0438\u0435 \u043d\u0430 \u043d\u0430\u0436\u0430\u0442\u0438\u0435 \u043a\u043b\u0430\u0432\u0438\u0448\u0438.", "1 \u56de\u306e\u30ad\u30fc\u5165\u529b\u306b\u3064\u304d 1 \u30e1\u30c3\u30bb\u30fc\u30b8\u3002"};
                break;
            }
            case "noAutoMessages": {
                values = new String[]{"N\u00e3o envia mensagens automaticamente.", "Messages are never sent automatically.", "No se env\u00edan mensajes autom\u00e1ticamente.", "\u0421\u043e\u043e\u0431\u0449\u0435\u043d\u0438\u044f \u043d\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u044e\u0442\u0441\u044f \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438.", "\u30e1\u30c3\u30bb\u30fc\u30b8\u306f\u81ea\u52d5\u9001\u4fe1\u3055\u308c\u307e\u305b\u3093\u3002"};
                break;
            }
            case "restoreKeys": {
                values = new String[]{"RESTAURAR TECLAS", "RESET KEYS", "RESTAURAR TECLAS", "\u0421\u0411\u0420\u041e\u0421\u0418\u0422\u042c \u041a\u041b\u0410\u0412\u0418\u0428\u0418", "\u30ad\u30fc\u3092\u521d\u671f\u5316"};
                break;
            }
            case "clearMacros": {
                values = new String[]{"LIMPAR MACROS", "CLEAR MACROS", "BORRAR MACROS", "\u041e\u0427\u0418\u0421\u0422\u0418\u0422\u042c \u041c\u0410\u041a\u0420\u041e\u0421\u042b", "\u30de\u30af\u30ed\u3092\u6d88\u53bb"};
                break;
            }
            case "pressKey": {
                values = new String[]{"PRESSIONE UMA TECLA...", "PRESS A KEY...", "PULSA UNA TECLA...", "\u041d\u0410\u0416\u041c\u0418\u0422\u0415 \u041a\u041b\u0410\u0412\u0418\u0428\u0423...", "\u30ad\u30fc\u3092\u62bc\u3057\u3066\u304f\u3060\u3055\u3044..."};
                break;
            }
            case "undefined": {
                values = new String[]{"N\u00c3O DEFINIDO", "UNASSIGNED", "SIN ASIGNAR", "\u041d\u0415 \u041d\u0410\u0417\u041d\u0410\u0427\u0415\u041d\u041e", "\u672a\u8a2d\u5b9a"};
                break;
            }
            case "chatTitle": {
                values = new String[]{"LUNARHAVENX CHAT", "LUNARHAVENX CHAT", "CHAT LUNARHAVENX", "\u0427\u0410\u0422 LUNARHAVENX", "LUNARHAVENX \u30c1\u30e3\u30c3\u30c8"};
                break;
            }
            case "emojis": {
                values = new String[]{"EMOJIS", "EMOJIS", "EMOJIS", "\u042d\u041c\u041e\u0414\u0417\u0418", "\u7d75\u6587\u5b57"};
                break;
            }
            case "openSettings": {
                values = new String[]{"Abrir configura\u00e7\u00f5es", "Open settings", "Abrir ajustes", "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438", "\u8a2d\u5b9a\u3092\u958b\u304f"};
                break;
            }
            case "toggleHud": {
                values = new String[]{"Alternar HUD", "Toggle HUD", "Alternar HUD", "\u041f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0438\u0442\u044c HUD", "HUD \u306e\u5207\u308a\u66ff\u3048"};
                break;
            }
            case "cyclePerformance": {
                values = new String[]{"Ciclar perfil de desempenho", "Cycle performance profile", "Cambiar perfil de rendimiento", "\u0421\u043c\u0435\u043d\u0438\u0442\u044c \u043f\u0440\u043e\u0444\u0438\u043b\u044c \u043f\u0440\u043e\u0438\u0437\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u0438", "\u30d1\u30d5\u30a9\u30fc\u30de\u30f3\u30b9\u8a2d\u5b9a\u3092\u5207\u308a\u66ff\u3048"};
                break;
            }
            case "openCosmetics": {
                values = new String[]{"Abrir cosm\u00e9ticos", "Open cosmetics", "Abrir cosm\u00e9ticos", "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u043a\u043e\u0441\u043c\u0435\u0442\u0438\u043a\u0443", "\u30b3\u30b9\u30e1\u3092\u958b\u304f"};
                break;
            }
            case "openServers": {
                values = new String[]{"Abrir servidores", "Open servers", "Abrir servidores", "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u0441\u0435\u0440\u0432\u0435\u0440\u044b", "\u30b5\u30fc\u30d0\u30fc\u3092\u958b\u304f"};
                break;
            }
            case "profileSlot": {
                values = new String[]{"ESPA\u00c7O", "SLOT", "ESPACIO", "\u0421\u041b\u041e\u0422", "\u30b9\u30ed\u30c3\u30c8"};
                break;
            }
            case "profileFileLabel": {
                values = new String[]{"ARQUIVO .LHXPROFILE \u2022 NOME SEM EXTENS\u00c3O", "PROFILE FILE \u2022 NAME WITHOUT EXTENSION", "ARCHIVO .LHXPROFILE \u2022 NOMBRE SIN EXTENSI\u00d3N", "\u0424\u0410\u0419\u041b .LHXPROFILE \u2022 \u0418\u041c\u042f \u0411\u0415\u0417 \u0420\u0410\u0421\u0428\u0418\u0420\u0415\u041d\u0418\u042f", "\u30d7\u30ed\u30d5\u30a3\u30fc\u30eb\u30d5\u30a1\u30a4\u30eb \u2022 \u62e1\u5f35\u5b50\u306a\u3057\u306e\u540d\u524d"};
                break;
            }
            case "profileFileHelp": {
                values = new String[]{"Local: config/lunarhavenx/profiles \u2022 clique em um nome para escolher o espa\u00e7o.", "Local: config/lunarhavenx/profiles \u2022 click a name field to choose the target slot.", "Local: config/lunarhavenx/profiles \u2022 pulsa un nombre para elegir el espacio.", "\u041f\u0430\u043f\u043a\u0430: config/lunarhavenx/profiles \u2022 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u0438\u043c\u044f, \u0447\u0442\u043e\u0431\u044b \u0432\u044b\u0431\u0440\u0430\u0442\u044c \u0441\u043b\u043e\u0442.", "\u4fdd\u5b58\u5148: config/lunarhavenx/profiles \u2022 \u540d\u524d\u6b04\u3092\u30af\u30ea\u30c3\u30af\u3057\u3066\u5bfe\u8c61\u30b9\u30ed\u30c3\u30c8\u3092\u9078\u629e\u3002"};
                break;
            }
            case "import": {
                values = new String[]{"IMPORTAR", "IMPORT", "IMPORTAR", "\u0418\u041c\u041f\u041e\u0420\u0422", "\u8aad\u307f\u8fbc\u307f"};
                break;
            }
            case "export": {
                values = new String[]{"EXPORTAR", "EXPORT", "EXPORTAR", "\u042d\u041a\u0421\u041f\u041e\u0420\u0422", "\u66f8\u304d\u51fa\u3057"};
                break;
            }
            case "profileApplied": {
                values = new String[]{"Perfil aplicado.", "Profile applied.", "Perfil aplicado.", "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u043f\u0440\u0438\u043c\u0435\u043d\u0451\u043d.", "\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u3092\u9069\u7528\u3057\u307e\u3057\u305f\u3002"};
                break;
            }
            case "profileSaved": {
                values = new String[]{"Perfil salvo com este nome.", "Profile saved with this name.", "Perfil guardado con este nombre.", "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d \u0441 \u044d\u0442\u0438\u043c \u0438\u043c\u0435\u043d\u0435\u043c.", "\u3053\u306e\u540d\u524d\u3067\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u3092\u4fdd\u5b58\u3057\u307e\u3057\u305f\u3002"};
                break;
            }
            case "profileImported": {
                values = new String[]{"Perfil importado e aplicado.", "Profile imported and applied.", "Perfil importado y aplicado.", "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u0438\u043c\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d \u0438 \u043f\u0440\u0438\u043c\u0435\u043d\u0451\u043d.", "\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u3092\u8aad\u307f\u8fbc\u307f\u3001\u9069\u7528\u3057\u307e\u3057\u305f\u3002"};
                break;
            }
            case "profileImportFailed": {
                values = new String[]{"Arquivo inv\u00e1lido ou n\u00e3o encontrado na pasta de perfis.", "File invalid or missing from the profiles folder.", "Archivo inv\u00e1lido o no encontrado en la carpeta de perfiles.", "\u0424\u0430\u0439\u043b \u043d\u0435\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043b\u0435\u043d \u0438\u043b\u0438 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d \u0432 \u043f\u0430\u043f\u043a\u0435 \u043f\u0440\u043e\u0444\u0438\u043b\u0435\u0439.", "\u30d7\u30ed\u30d5\u30a3\u30fc\u30eb\u30d5\u30a9\u30eb\u30c0\u30fc\u306b\u30d5\u30a1\u30a4\u30eb\u304c\u306a\u3044\u304b\u3001\u5f62\u5f0f\u304c\u4e0d\u6b63\u3067\u3059\u3002"};
                break;
            }
            case "profileExported": {
                values = new String[]{"Perfil exportado para a pasta de perfis.", "Profile exported to the profiles folder.", "Perfil exportado a la carpeta de perfiles.", "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u044d\u043a\u0441\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d \u0432 \u043f\u0430\u043f\u043a\u0443 \u043f\u0440\u043e\u0444\u0438\u043b\u0435\u0439.", "\u30d7\u30ed\u30d5\u30a3\u30fc\u30eb\u30d5\u30a9\u30eb\u30c0\u30fc\u3078\u66f8\u304d\u51fa\u3057\u307e\u3057\u305f\u3002"};
                break;
            }
            case "profileExportFailed": {
                values = new String[]{"N\u00e3o foi poss\u00edvel exportar. Use um nome simples de arquivo.", "Export failed. Use a simple file name.", "No se pudo exportar. Usa un nombre de archivo sencillo.", "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u044d\u043a\u0441\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c. \u0418\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435 \u043f\u0440\u043e\u0441\u0442\u043e\u0435 \u0438\u043c\u044f \u0444\u0430\u0439\u043b\u0430.", "\u66f8\u304d\u51fa\u3057\u5931\u6557\u3002\u30b7\u30f3\u30d7\u30eb\u306a\u30d5\u30a1\u30a4\u30eb\u540d\u3092\u4f7f\u3063\u3066\u304f\u3060\u3055\u3044\u3002"};
                break;
            }
            case "editHud": {
                values = new String[]{"EDITAR POSI\u00c7\u00c3O DO HUD", "EDIT HUD LAYOUT", "EDITAR POSICI\u00d3N DEL HUD", "\u0418\u0417\u041c\u0415\u041d\u0418\u0422\u042c HUD", "HUD \u306e\u914d\u7f6e\u3092\u7de8\u96c6"};
                break;
            }
            case "hudEditorTitle": {
                values = new String[]{"EDITOR DO HUD", "HUD EDITOR", "EDITOR DEL HUD", "\u0420\u0415\u0414\u0410\u041a\u0422\u041e\u0420 HUD", "HUD \u30a8\u30c7\u30a3\u30bf\u30fc"};
                break;
            }
            case "hudEditorHelp": {
                values = new String[]{"Arraste os pain\u00e9is para reposicionar \u2022 posi\u00e7\u00f5es salvas por resolu\u00e7\u00e3o", "Drag panels to reposition \u2022 positions adapt to resolution", "Arrastra paneles \u2022 posiciones adaptables a la resoluci\u00f3n", "\u041f\u0435\u0440\u0435\u0442\u0430\u0441\u043a\u0438\u0432\u0430\u0439\u0442\u0435 \u043f\u0430\u043d\u0435\u043b\u0438 \u2022 \u043f\u043e\u0437\u0438\u0446\u0438\u0438 \u043f\u043e\u0434\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u044e\u0442\u0441\u044f \u043f\u043e\u0434 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u0435", "\u30d1\u30cd\u30eb\u3092\u30c9\u30e9\u30c3\u30b0\u3057\u3066\u914d\u7f6e \u2022 \u89e3\u50cf\u5ea6\u306b\u5408\u308f\u305b\u3066\u4fdd\u5b58"};
                break;
            }
            case "hudReset": {
                values = new String[]{"RESTAURAR POSI\u00c7\u00d5ES", "RESET POSITIONS", "RESTABLECER POSICIONES", "\u0421\u0411\u0420\u041e\u0421\u0418\u0422\u042c \u041f\u041e\u0417\u0418\u0426\u0418\u0418", "\u4f4d\u7f6e\u3092\u30ea\u30bb\u30c3\u30c8"};
                break;
            }
            case "hudElementInfo": {
                values = new String[]{"Informa\u00e7\u00f5es", "Info panel", "Informaci\u00f3n", "\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f", "\u60c5\u5831"};
                break;
            }
            case "playerStatus": {
                values = new String[]{"STATUS DO JOGADOR", "PLAYER STATUS", "ESTADO DEL JUGADOR", "\u0421\u0422\u0410\u0422\u0423\u0421 \u0418\u0413\u0420\u041e\u041a\u0410", "\u30d7\u30ec\u30a4\u30e4\u30fc\u72b6\u614b"};
                break;
            }
            case "health": {
                values = new String[]{"VIDA", "HEALTH", "VIDA", "\u0417\u0414\u041e\u0420\u041e\u0412\u042c\u0415", "\u4f53\u529b"};
                break;
            }
            case "hunger": {
                values = new String[]{"FOME", "HUNGER", "HAMBRE", "\u0413\u041e\u041b\u041e\u0414", "\u7a7a\u8179\u5ea6"};
                break;
            }
            case "noEffects": {
                values = new String[]{"Nenhum efeito ativo", "No active effects", "Sin efectos activos", "\u041d\u0435\u0442 \u0430\u043a\u0442\u0438\u0432\u043d\u044b\u0445 \u044d\u0444\u0444\u0435\u043a\u0442\u043e\u0432", "\u52b9\u679c\u306a\u3057"};
                break;
            }
            case "effect": {
                values = new String[]{"Efeito", "Effect", "Efecto", "\u042d\u0444\u0444\u0435\u043a\u0442", "\u52b9\u679c"};
                break;
            }
            case "sneak": {
                values = new String[]{"AGACHAR", "SNEAK", "AGACHARSE", "\u041a\u0420\u0410\u0421\u0422\u042c\u0421\u042f", "\u30b9\u30cb\u30fc\u30af"};
                break;
            }
            case "sneaking": {
                values = new String[]{"AGACHADO", "SNEAKING", "AGACHADO", "\u041a\u0420\u0410\u0414\u0401\u0422\u0421\u042f", "\u30b9\u30cb\u30fc\u30af\u4e2d"};
                break;
            }
            case "sprint": {
                values = new String[]{"CORRER", "SPRINT", "CORRER", "\u0411\u0415\u0413", "\u30c0\u30c3\u30b7\u30e5"};
                break;
            }
            case "sprinting": {
                values = new String[]{"CORRENDO", "SPRINTING", "CORRIENDO", "\u0411\u0415\u0416\u0418\u0422", "\u30c0\u30c3\u30b7\u30e5\u4e2d"};
                break;
            }
            case "leftClick": {
                values = new String[]{"ESQ", "L", "IZQ", "\u041b\u041a\u041c", "\u5de6"};
                break;
            }
            case "rightClick": {
                values = new String[]{"DIR", "R", "DER", "\u041f\u041a\u041c", "\u53f3"};
                break;
            }
            case "perfPotato": {
                values = new String[]{"BATATA", "VERY LOW", "MUY BAJO", "\u041c\u0418\u041d\u0418\u041c\u0410\u041b\u042c\u041d\u042b\u0419", "\u6700\u4f4e"};
                break;
            }
            case "perfLow": {
                values = new String[]{"BAIXO", "LOW", "BAJO", "\u041d\u0418\u0417\u041a\u0418\u0419", "\u4f4e"};
                break;
            }
            case "perfBalanced": {
                values = new String[]{"BALANCEADO", "BALANCED", "EQUILIBRADO", "\u0421\u0411\u0410\u041b\u0410\u041d\u0421\u0418\u0420\u041e\u0412\u0410\u041d\u041d\u042b\u0419", "\u6a19\u6e96"};
                break;
            }
            case "perfHigh": {
                values = new String[]{"ALTO FPS", "HIGH FPS", "FPS ALTO", "\u0412\u042b\u0421\u041e\u041a\u0418\u0419 FPS", "\u9ad8 FPS"};
                break;
            }
            case "perfExtreme": {
                values = new String[]{"FPS EXTREMO", "EXTREME FPS", "FPS EXTREMO", "\u042d\u041a\u0421\u0422\u0420\u0415\u041c\u0410\u041b\u042c\u041d\u042b\u0419 FPS", "FPS \u512a\u5148"};
                break;
            }
            case "perfMobile": {
                values = new String[]{"CELULAR FRACO", "LOW-END MOBILE", "M\u00d3VIL B\u00c1SICO", "\u0421\u041b\u0410\u0411\u042b\u0419 \u0422\u0415\u041b\u0415\u0424\u041e\u041d", "\u4f4e\u6027\u80fd\u7aef\u672b"};
                break;
            }
            case "loadingTitle": {
                values = new String[]{"CARREGANDO M\u00d3DULOS...", "LOADING MODULES...", "CARGANDO M\u00d3DULOS...", "\u0417\u0410\u0413\u0420\u0423\u0417\u041a\u0410 \u041c\u041e\u0414\u0423\u041b\u0415\u0419...", "\u30e2\u30b8\u30e5\u30fc\u30eb\u3092\u8aad\u307f\u8fbc\u307f\u4e2d..."};
                break;
            }
            case "resourceSection": {
                values = new String[]{"RECURSOS DO CLIENTE", "CLIENT FEATURES", "RECURSOS DEL CLIENTE", "\u0412\u041e\u0417\u041c\u041e\u0416\u041d\u041e\u0421\u0422\u0418 \u041a\u041b\u0418\u0415\u041d\u0422\u0410", "\u30af\u30e9\u30a4\u30a2\u30f3\u30c8\u6a5f\u80fd"};
                break;
            }
            case "featureHud": {
                values = new String[]{"HUD AVAN\u00c7ADO", "ADVANCED HUD", "HUD AVANZADO", "\u0420\u0410\u0421\u0428\u0418\u0420\u0415\u041d\u041d\u042b\u0419 HUD", "\u62e1\u5f35 HUD"};
                break;
            }
            case "featureHudDesc": {
                values = new String[]{"CPS, teclas, FPS e armadura", "CPS, keys, FPS and armor", "CPS, teclas, FPS y armadura", "CPS, \u043a\u043b\u0430\u0432\u0438\u0448\u0438, FPS \u0438 \u0431\u0440\u043e\u043d\u044f", "CPS\u3001\u30ad\u30fc\u3001FPS\u3001\u9632\u5177"};
                break;
            }
            case "featurePerformance": {
                values = new String[]{"DESEMPENHO", "PERFORMANCE", "RENDIMIENTO", "\u041f\u0420\u041e\u0418\u0417\u0412\u041e\u0414\u0418\u0422\u0415\u041b\u042c\u041d\u041e\u0421\u0422\u042c", "\u30d1\u30d5\u30a9\u30fc\u30de\u30f3\u30b9"};
                break;
            }
            case "featurePerformanceDesc": {
                values = new String[]{"Perfis gr\u00e1ficos e modo leve", "Graphics profiles and low-end mode", "Perfiles gr\u00e1ficos y modo ligero", "\u0413\u0440\u0430\u0444\u0438\u0447\u0435\u0441\u043a\u0438\u0435 \u043f\u0440\u043e\u0444\u0438\u043b\u0438 \u0438 \u043b\u0451\u0433\u043a\u0438\u0439 \u0440\u0435\u0436\u0438\u043c", "\u753b\u8cea\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u3068\u8efd\u91cf\u30e2\u30fc\u30c9"};
                break;
            }
            case "featureEly": {
                values = new String[]{"ELY.BY", "ELY.BY", "ELY.BY", "ELY.BY", "ELY.BY"};
                break;
            }
            case "featureElyDesc": {
                values = new String[]{"Em servidores compat\u00edveis", "On compatible servers", "En servidores compatibles", "\u041d\u0430 \u0441\u043e\u0432\u043c\u0435\u0441\u0442\u0438\u043c\u044b\u0445 \u0441\u0435\u0440\u0432\u0435\u0440\u0430\u0445", "\u5bfe\u5fdc\u30b5\u30fc\u30d0\u30fc\u3067\u5229\u7528\u53ef\u80fd"};
                break;
            }
            case "featureCosmetics": {
                values = new String[]{"COSM\u00c9TICOS", "COSMETICS", "COSM\u00c9TICOS", "\u041a\u041e\u0421\u041c\u0415\u0422\u0418\u041a\u0410", "\u30b3\u30b9\u30e1"};
                break;
            }
            case "featureCosmeticsDesc": {
                values = new String[]{"Capas originais locais", "Original local capes", "Capas originales locales", "\u041e\u0440\u0438\u0433\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u0435 \u043b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0435 \u043f\u043b\u0430\u0449\u0438", "\u30aa\u30ea\u30b8\u30ca\u30eb\u306e\u30ed\u30fc\u30ab\u30eb\u30de\u30f3\u30c8"};
                break;
            }
            case "featureShortcuts": {
                values = new String[]{"ATALHOS", "KEYBINDS", "ATAJOS", "\u041a\u041b\u0410\u0412\u0418\u0428\u0418", "\u30ad\u30fc\u8a2d\u5b9a"};
                break;
            }
            case "featureShortcutsDesc": {
                values = new String[]{"Configura\u00e7\u00f5es r\u00e1pidas no jogo", "Quick in-game settings", "Ajustes r\u00e1pidos en el juego", "\u0411\u044b\u0441\u0442\u0440\u044b\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0432 \u0438\u0433\u0440\u0435", "\u30b2\u30fc\u30e0\u5185\u306e\u30af\u30a4\u30c3\u30af\u8a2d\u5b9a"};
                break;
            }
            case "loadingInitial": {
                values = new String[]{"INICIANDO...", "STARTING...", "INICIANDO...", "\u0417\u0410\u041f\u0423\u0421\u041a...", "\u8d77\u52d5\u4e2d..."};
                break;
            }
            case "loadingPrepare": {
                values = new String[]{"PREPARANDO CLIENTE...", "PREPARING CLIENT...", "PREPARANDO CLIENTE...", "\u041f\u041e\u0414\u0413\u041e\u0422\u041e\u0412\u041a\u0410 \u041a\u041b\u0418\u0415\u041d\u0422\u0410...", "\u30af\u30e9\u30a4\u30a2\u30f3\u30c8\u3092\u6e96\u5099\u4e2d..."};
                break;
            }
            case "loadingResources": {
                values = new String[]{"TEXTURA E RECURSOS VALIDADOS", "TEXTURE AND RESOURCES READY", "TEXTURA Y RECURSOS VALIDADOS", "\u0422\u0415\u041a\u0421\u0422\u0423\u0420\u042b \u0418 \u0420\u0415\u0421\u0423\u0420\u0421\u042b \u041f\u0420\u041e\u0412\u0415\u0420\u0415\u041d\u042b", "\u30c6\u30af\u30b9\u30c1\u30e3\u3068\u30ea\u30bd\u30fc\u30b9\u3092\u78ba\u8a8d\u3057\u307e\u3057\u305f"};
                break;
            }
            case "loadingFallback": {
                values = new String[]{"TEXTURA AUSENTE \u2014 FUNDO DE SEGURAN\u00c7A ATIVO", "TEXTURE MISSING \u2014 FALLBACK BACKGROUND", "TEXTURA AUSENTE \u2014 FONDO ALTERNATIVO", "\u0422\u0415\u041a\u0421\u0422\u0423\u0420\u0410 \u041d\u0415 \u041d\u0410\u0419\u0414\u0415\u041d\u0410 \u2014 \u0420\u0415\u0417\u0415\u0420\u0412\u041d\u042b\u0419 \u0424\u041e\u041d", "\u30c6\u30af\u30b9\u30c1\u30e3\u306a\u3057 \u2014 \u4ee3\u66ff\u80cc\u666f\u3092\u4f7f\u7528"};
                break;
            }
            case "loadingPreferences": {
                values = new String[]{"PREFER\u00caNCIAS CARREGADAS", "PREFERENCES LOADED", "PREFERENCIAS CARGADAS", "\u041d\u0410\u0421\u0422\u0420\u041e\u0419\u041a\u0418 \u0417\u0410\u0413\u0420\u0423\u0416\u0415\u041d\u042b", "\u8a2d\u5b9a\u3092\u8aad\u307f\u8fbc\u307f\u307e\u3057\u305f"};
                break;
            }
            case "loadingReady": {
                values = new String[]{"ATALHOS E COSM\u00c9TICOS PRONTOS", "KEYBINDS AND COSMETICS READY", "ATAJOS Y COSM\u00c9TICOS LISTOS", "\u041a\u041b\u0410\u0412\u0418\u0428\u0418 \u0418 \u041a\u041e\u0421\u041c\u0415\u0422\u0418\u041a\u0410 \u0413\u041e\u0422\u041e\u0412\u042b", "\u30ad\u30fc\u8a2d\u5b9a\u3068\u30b3\u30b9\u30e1\u306e\u6e96\u5099\u5b8c\u4e86"};
                break;
            }
            case "loadingPlay": {
                values = new String[]{"PRONTO PARA JOGAR", "READY TO PLAY", "LISTO PARA JUGAR", "\u0413\u041e\u0422\u041e\u0412\u041e \u041a \u0418\u0413\u0420\u0415", "\u30d7\u30ec\u30a4\u3067\u304d\u307e\u3059"};
                break;
            }
            case "loadingFallbackReady": {
                values = new String[]{"PRONTO \u2022 FUNDO DE SEGURAN\u00c7A", "READY \u2022 FALLBACK BACKGROUND", "LISTO \u2022 FONDO ALTERNATIVO", "\u0413\u041e\u0422\u041e\u0412\u041e \u2022 \u0420\u0415\u0417\u0415\u0420\u0412\u041d\u042b\u0419 \u0424\u041e\u041d", "\u6e96\u5099\u5b8c\u4e86 \u2022 \u4ee3\u66ff\u80cc\u666f"};
                break;
            }
            case "loadingCompatibility": {
                values = new String[]{"HUD \u2022 PERFIL LEVE \u2022 ELY.BY COMPAT\u00cdVEL", "HUD \u2022 LOW-END PROFILE \u2022 ELY.BY READY", "HUD \u2022 PERFIL LIGERO \u2022 ELY.BY COMPATIBLE", "HUD \u2022 \u041b\u0401\u0413\u041a\u0418\u0419 \u041f\u0420\u041e\u0424\u0418\u041b\u042c \u2022 ELY.BY", "HUD \u2022 \u8efd\u91cf\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb \u2022 ELY.BY \u5bfe\u5fdc"};
                break;
            }
            case "statVersion": {
                values = new String[]{"VERS\u00c3O", "VERSION", "VERSI\u00d3N", "\u0412\u0415\u0420\u0421\u0418\u042f", "\u30d0\u30fc\u30b8\u30e7\u30f3"};
                break;
            }
            case "statFps": {
                values = new String[]{"FPS", "FPS", "FPS", "FPS", "FPS"};
                break;
            }
            case "statProfile": {
                values = new String[]{"PERFIL", "PROFILE", "PERFIL", "\u041f\u0420\u041e\u0424\u0418\u041b\u042c", "\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb"};
                break;
            }
            case "statPlatform": {
                values = new String[]{"PLATAFORMA", "PLATFORM", "PLATAFORMA", "\u041f\u041b\u0410\u0422\u0424\u041e\u0420\u041c\u0410", "\u30d7\u30e9\u30c3\u30c8\u30d5\u30a9\u30fc\u30e0"};
                break;
            }
            case "android": {
                values = new String[]{"ANDROID", "ANDROID", "ANDROID", "ANDROID", "ANDROID"};
                break;
            }
            case "desktop": {
                values = new String[]{"DESKTOP", "DESKTOP", "ESCRITORIO", "\u041f\u041a", "\u30c7\u30b9\u30af\u30c8\u30c3\u30d7"};
                break;
            }
            case "tipAndroid": {
                values = new String[]{"DICA: configure os controles de toque no MJLauncher.", "TIP: configure touch controls in MJLauncher.", "CONSEJO: configura los controles t\u00e1ctiles en MJLauncher.", "\u0421\u041e\u0412\u0415\u0422: \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u0442\u0435 \u0441\u0435\u043d\u0441\u043e\u0440\u043d\u043e\u0435 \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 \u0432 MJLauncher.", "\u30d2\u30f3\u30c8: MJLauncher \u3067\u30bf\u30c3\u30c1\u64cd\u4f5c\u3092\u8a2d\u5b9a\u3057\u3066\u304f\u3060\u3055\u3044\u3002"};
                break;
            }
            case "tipDesktop": {
                values = new String[]{"DICA: RSHIFT abre configura\u00e7\u00f5es \u2022 F7 alterna perfis.", "TIP: RSHIFT opens settings \u2022 F7 cycles profiles.", "CONSEJO: RSHIFT abre ajustes \u2022 F7 cambia perfiles.", "\u0421\u041e\u0412\u0415\u0422: RSHIFT \u2014 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u2022 F7 \u2014 \u0441\u043c\u0435\u043d\u0430 \u043f\u0440\u043e\u0444\u0438\u043b\u044f.", "\u30d2\u30f3\u30c8: RSHIFT \u3067\u8a2d\u5b9a\u3001F7 \u3067\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u5207\u66ff\u3002"};
                break;
            }
            default: {
                return key;
            }
        }
        return values[this.language];
    }

    public String performanceName(String id) {
        if ("BATATA".equals(id)) {
            return this.text("perfPotato");
        }
        if ("BAIXO".equals(id)) {
            return this.text("perfLow");
        }
        if ("BALANCEADO".equals(id)) {
            return this.text("perfBalanced");
        }
        if ("ALTO_FPS".equals(id)) {
            return this.text("perfHigh");
        }
        if ("FPS_EXTREMO".equals(id)) {
            return this.text("perfExtreme");
        }
        if ("CELULAR_FRACO".equals(id)) {
            return this.text("perfMobile");
        }
        return id;
    }

    private void load() {
        if (!this.file.isFile()) {
            return;
        }
        Properties p = new Properties();
        try {
            try (FileInputStream in = new FileInputStream(this.file);){
                p.load(in);
            }
            this.language = Math.max(0, Math.min(NAMES.length - 1, Integer.parseInt(p.getProperty("language", "0"))));
        }
        catch (Exception ignored) {
            this.language = 0;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void save() {
        File parent = this.file.getParentFile();
        if (!parent.exists() && !parent.mkdirs()) {
            return;
        }
        Properties p = new Properties();
        p.setProperty("language", String.valueOf(this.language));
        try (FileOutputStream out = new FileOutputStream(this.file);){
            p.store(out, "LunarHavenX interface language");
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }
}


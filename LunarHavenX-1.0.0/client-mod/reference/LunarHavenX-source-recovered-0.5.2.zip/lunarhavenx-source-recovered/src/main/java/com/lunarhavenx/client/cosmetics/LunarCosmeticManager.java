/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client.cosmetics;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import net.minecraft.client.Minecraft;

public final class LunarCosmeticManager {
    private static final LunarCosmeticManager INSTANCE = new LunarCosmeticManager();
    private final File file;
    private Cape cape = Cape.NONE;

    private LunarCosmeticManager() {
        this.file = new File(Minecraft.getMinecraft().mcDataDir, "config/lunarhavenx/cosmetics.properties");
        this.load();
    }

    public static LunarCosmeticManager get() {
        return INSTANCE;
    }

    public Cape getCape() {
        return this.cape;
    }

    public void setCape(Cape cape) {
        this.cape = cape == null ? Cape.NONE : cape;
        this.save();
    }

    public void load() {
        if (!this.file.isFile()) {
            return;
        }
        Properties p = new Properties();
        try {
            try (FileInputStream in = new FileInputStream(this.file);){
                p.load(in);
            }
            try {
                this.cape = Cape.valueOf(p.getProperty("cape", this.cape.name()));
            }
            catch (IllegalArgumentException ignored) {
                this.cape = Cape.NONE;
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void save() {
        File parent = this.file.getParentFile();
        if (!parent.exists() && !parent.mkdirs()) {
            return;
        }
        Properties p = new Properties();
        p.setProperty("cape", this.cape.name());
        try (FileOutputStream out = new FileOutputStream(this.file);){
            p.store(out, "LunarHavenX local cosmetics");
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    public static enum Cape {
        NONE("SEM CAPA", ""),
        LUNAR("LUNAR", "textures/cosmetics/cape_lunar.png"),
        HAVEN("HAVEN", "textures/cosmetics/cape_haven.png"),
        AURORA("AURORA", "textures/cosmetics/cape_aurora.png"),
        NOVA("NOVA", "textures/cosmetics/cape_nova.png");

        public final String label;
        public final String texture;

        private Cape(String label, String texture) {
            this.label = label;
            this.texture = texture;
        }

        public Cape next() {
            return Cape.values()[(this.ordinal() + 1) % Cape.values().length];
        }
    }
}


/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client;

import com.lunarhavenx.client.gui.GuiLunarChat;
import com.lunarhavenx.client.gui.GuiLunarLoading;
import com.lunarhavenx.client.hud.LunarHudOverlay;
import com.lunarhavenx.client.input.LunarKeybindManager;
import com.lunarhavenx.client.mobile.LunarMobileCompatibility;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

@Mod(modid="lunarhavenx", name="LunarHavenX Client", version="0.5.2-alpha", acceptedMinecraftVersions="[1.8.9]")
public class LunarHavenXMod {
    public static final String MOD_ID = "lunarhavenx";
    public static final String NAME = "LunarHavenX Client";
    public static final String VERSION = "0.5.2-alpha";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register((Object)this);
        MinecraftForge.EVENT_BUS.register((Object)new LunarHudOverlay());
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        LunarKeybindManager.get().register();
        LunarMobileCompatibility.applyRecommendedSettings();
    }

    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
        if (event.gui instanceof GuiChat && !(event.gui instanceof GuiLunarChat)) {
            event.gui = new GuiLunarChat();
            return;
        }
        if (event.gui instanceof GuiMainMenu) {
            event.gui = new GuiLunarLoading();
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            LunarKeybindManager.get().tick();
        }
    }
}


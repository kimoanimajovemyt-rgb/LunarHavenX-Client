/*
 * Decompiled with CFR 0.152.
 */
package com.lunarhavenx.client.gui;

import com.lunarhavenx.client.config.LunarLanguageManager;
import com.lunarhavenx.client.cosmetics.LunarCosmeticManager;
import com.lunarhavenx.client.gui.LunarButton;
import com.lunarhavenx.client.gui.LunarUi;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

public class GuiLunarCosmetics
extends GuiScreen {
    private static final ResourceLocation BACKGROUND = new ResourceLocation("lunarhavenx", "textures/gui/loading_background.png");
    private final LunarCosmeticManager cosmetics = LunarCosmeticManager.get();
    private final LunarLanguageManager language = LunarLanguageManager.get();
    private final GuiScreen parent;
    private LunarCosmeticManager.Cape preview;
    private String notice = "";
    private long noticeUntil;

    public GuiLunarCosmetics() {
        this(null);
    }

    public GuiLunarCosmetics(GuiScreen parent) {
        this.parent = parent;
    }

    public void initGui() {
        this.preview = this.cosmetics.getCape();
        this.buttonList.clear();
        this.buttonList.add(new LunarButton(0, this.width / 2 - 155, this.height - 75, 95, 25, this.language.text("previous")));
        this.buttonList.add(new LunarButton(1, this.width / 2 - 50, this.height - 75, 100, 25, this.language.text("equip"), true));
        this.buttonList.add(new LunarButton(2, this.width / 2 + 60, this.height - 75, 95, 25, this.language.text("next")));
        this.buttonList.add(new LunarButton(3, this.width / 2 - 50, this.height - 42, 100, 22, this.language.text("back")));
    }

    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 0: {
                this.preview = this.previous(this.preview);
                break;
            }
            case 1: {
                this.cosmetics.setCape(this.preview);
                this.notice = this.language.text("equipped") + " " + this.preview.label + " " + this.language.text("equippedLocal");
                this.noticeUntil = System.currentTimeMillis() + 2200L;
                break;
            }
            case 2: {
                this.preview = this.preview.next();
                break;
            }
            case 3: {
                this.mc.displayGuiScreen(this.parent);
            }
        }
    }

    private LunarCosmeticManager.Cape previous(LunarCosmeticManager.Cape value) {
        LunarCosmeticManager.Cape[] all = LunarCosmeticManager.Cape.values();
        return all[(value.ordinal() + all.length - 1) % all.length];
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (LunarUi.hasTexture(BACKGROUND)) {
            this.mc.getTextureManager().bindTexture(BACKGROUND);
            GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GuiLunarCosmetics.drawModalRectWithCustomSizedTexture((int)0, (int)0, (float)0.0f, (float)0.0f, (int)this.width, (int)this.height, (float)1280.0f, (float)720.0f);
        } else {
            GuiLunarCosmetics.drawRect((int)0, (int)0, (int)this.width, (int)this.height, (int)-16446684);
        }
        GuiLunarCosmetics.drawRect((int)0, (int)0, (int)this.width, (int)this.height, (int)-654045151);
        LunarUi.drawHeading(this.language.text("cosmetics"), this.language.text("cosmeticSubtitle"), this.width, 24);
        int cardLeft = this.width / 2 - 164;
        int cardTop = 70;
        LunarUi.drawPanel(cardLeft, cardTop, 328, 190, true);
        this.drawCenteredString(this.fontRendererObj, this.preview.label, this.width / 2, cardTop + 16, -919553);
        if (this.preview != LunarCosmeticManager.Cape.NONE) {
            ResourceLocation texture = new ResourceLocation("lunarhavenx", this.preview.texture);
            if (LunarUi.hasTexture(texture)) {
                this.mc.getTextureManager().bindTexture(texture);
                GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                GuiLunarCosmetics.drawModalRectWithCustomSizedTexture((int)(this.width / 2 - 96), (int)(cardTop + 48), (float)0.0f, (float)0.0f, (int)192, (int)96, (float)64.0f, (float)32.0f);
            } else {
                this.drawCenteredString(this.fontRendererObj, this.language.text("textureMissing"), this.width / 2, cardTop + 88, -6572852);
            }
        } else {
            this.drawCenteredString(this.fontRendererObj, this.language.text("noCape"), this.width / 2, cardTop + 86, -6572852);
        }
        this.drawCenteredString(this.fontRendererObj, this.language.text("selectedCape") + "  \u2022  " + this.cosmetics.getCape().label, this.width / 2, cardTop + 158, -11150849);
        this.drawCenteredString(this.fontRendererObj, this.language.text("elyByInfo"), this.width / 2, this.height - 119, -6572852);
        this.drawCenteredString(this.fontRendererObj, this.language.text("elyByHelp"), this.width / 2, this.height - 105, -6572852);
        this.drawCenteredString(this.fontRendererObj, this.language.text("localCapeInfo"), this.width / 2, this.height - 91, -6572852);
        if (System.currentTimeMillis() < this.noticeUntil) {
            this.drawCenteredString(this.fontRendererObj, this.notice, this.width / 2, this.height - 15, -919553);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    public boolean doesGuiPauseGame() {
        return false;
    }
}


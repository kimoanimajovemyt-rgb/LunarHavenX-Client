# LunarHavenX Client — fontes recuperados

Este diretório contém uma reconstrução das fontes do JAR `LunarHavenX-Client-1.8.9-0.5.2-alpha`.

## Conteúdo

- 23 arquivos Java decompilados, com nomes de métodos e campos remapeados para MCP `stable_22` (Minecraft 1.8.9).
- Recursos originais do mod: texturas, idiomas e `mcmod.info`.
- Configuração inicial do ForgeGradle para Forge 1.8.9.

## Compilação

Use Java 8 e Gradle 2.14.1, necessários para o ForgeGradle 2.1 usado pela geração do Minecraft 1.8.9:

```sh
gradle setupDecompWorkspace
gradle build
```

O JAR compilado será criado em `build/libs/`.

## Limitações da recuperação

As fontes foram reconstruídas a partir de bytecode com CFR 0.152. Elas preservam a lógica que o bytecode permite recuperar, mas não os comentários, nomes locais, formatação ou estrutura exata do código original. O processo também pode não recuperar construções de linguagem ou informações que o compilador removeu. O JAR original não incluía fontes nem símbolos de depuração.

Os recursos e metadados foram copiados do JAR fornecido. A recuperação não concede direitos adicionais sobre o código, os nomes ou os recursos do mod.
